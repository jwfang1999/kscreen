<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# main.php is part of K-Screen Version 1.1.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#
// uncomment the following to define a path alias
// Yii::setPathOfAlias('local','path/to/local-folder');

// This is the mainmain Web application configuration. Any writable
// CWebApplication properties can be configured here.

//Logo Image
Yii::app()->params->logoImg					= 'images/kscreenlogo6.png'; //set to false to display message only
Yii::app()->params->logoMsg					= Yii::app()->name;

//Molecule Image Data
Yii::app()->params->imgDir					= 'kscreen-release/file_store/bitmaps/'; //location of images for molecules

//Batch SQL Settings
Yii::app()->params->recordsPerInsert        = 1000; //Maximum number of records for big batch insert (too big and mysql server may cut off input).

//Search Settings
Yii::app()->params->maxPScreens             = 5; //Maximum number of Primary Screens searchable at the same time.  It is not recommended that this be set to a large number.
Yii::app()->params->maxResults              = 50000;
Yii::app()->params->realMaxSimiliarityCands = 50000; //Maximum number of POSSIBLE similarity hits;
Yii::app()->params->maxSimiliarityCands     = min(array(Yii::app()->params->realMaxSimiliarityCands,Yii::app()->params->maxResults));
Yii::app()->params->realMaxSubExactCands    = 5000; //Maximum number of POSSIBLE substructure hits;
Yii::app()->params->maxSubExactCands     	= min(array(Yii::app()->params->realMaxSubExactCands,Yii::app()->params->maxResults));
Yii::app()->params->maxResultsPerPage       = 50;

//Scatter Plot Defaults
Yii::app()->params->minScatter		        = 20;
Yii::app()->params->maxScatter		        = 80;

//Structural Search Applet
Yii::app()->params->appletDir               = 'applets/'; //Location of Applets
Yii::app()->params->structAppletName        = 'JME'; // Name of Applet for molecular similarity

//Missing Mol Image
Yii::app()->params->missingMolImg           = 'images/invalid.png';

//Loading Animation
Yii::app()->params->loadingImg              = 'images/kscreen_loading.gif';
Yii::app()->params->loadingHtml             = '<div style = "height:100px;"></div><img class = "loading" src = "%1/'.Yii::app()->params->loadingImg.'"><div class = "center_text">LOADING...</div>';

//Upload Settings
Yii::app()->params->largestBlob				= 50; //In MB
Yii::app()->params->tempDir		            = 'tmp/';

Yii::app()->params->assetsDir               = 'protected/kscreen_assets/';
Yii::app()->params->defaultConfFile         = 'default_plate_config.csv';
Yii::app()->params->sortTablesFile	        = 'sorttable.js';
Yii::app()->params->defaultConfFileDir      = Yii::app()->params->assetsDir.Yii::app()->params->defaultConfFile;

//Allows clients the ability to download whole database, set allowAllMolSDF to false to disallow.
Yii::app()->params->allowAllMolSDF          = true;
Yii::app()->params->allMolSDF               = 'MolBrowseResults';
//Yii::app()->params->allMolSDFDir            = Yii::app()->params->assetsDir.Yii::app()->params->allMolSDF;

Yii::app()->params->uploadDir               = "protected/kscreen_uploads/";
Yii::app()->params->pscreenUploadDir        = Yii::app()->params->uploadDir.'pscreens/';
Yii::app()->params->pscreenDataUploadDir    = Yii::app()->params->uploadDir.'pscreens/%1/';
Yii::app()->params->pscreenRawUploadDir     = Yii::app()->params->pscreenDataUploadDir.'raw/';
Yii::app()->params->pscreenSummaryUploadDir = Yii::app()->params->pscreenDataUploadDir.'summary/';
Yii::app()->params->pscreenReportUploadDir  = Yii::app()->params->pscreenDataUploadDir.'report/';

Yii::app()->params->sscreenUploadDir        = Yii::app()->params->pscreenDataUploadDir.'sscreens/';
Yii::app()->params->sscreenDataUploadDir    = Yii::app()->params->sscreenUploadDir.'%2/';
Yii::app()->params->sscreenRawUploadDir     = Yii::app()->params->sscreenDataUploadDir.'raw/';
Yii::app()->params->sscreenReportUploadDir  = Yii::app()->params->sscreenDataUploadDir.'report/';

Yii::app()->params->logFile             	= 'log.log';
Yii::app()->params->reportFile	         	= 'report.zip';

//	User Cache Settings
Yii::app()->params->cacheDir               	= 'protected/kscreen_user_cache/';
Yii::app()->params->usercacheDir            = 'protected/kscreen_user_cache/%1/';
Yii::app()->params->userSearchCacheDir      = 'protected/kscreen_user_cache/%1/searches/';
Yii::app()->params->searchCacheFilePrefix   = 'SK_';

Yii::app()->params->cacheFilePrefix         = 'CACHE_';
Yii::app()->params->cacheFileFormat         = 'cache';

//  Bin Directory
	Yii::app()->params->binDir              = 'protected/kscreen_bin/';
if(preg_match('/WIN/i',PHP_OS)) //Windows Binaries
{
	Yii::app()->params->checkMatchMolDir    = Yii::app()->params->binDir.'check_match_mol_win/';
	Yii::app()->params->checkMolExec   		= '"'.Yii::app()->params->checkMatchMolDir.'checkmol.exe"';
	Yii::app()->params->matchMolExec   		= '"'.Yii::app()->params->checkMatchMolDir.'matchmol.exe"';
}
else //Linux Binaries
{
	Yii::app()->params->checkMatchMolDir    = Yii::app()->params->binDir.'check_match_mol_nix/';
	Yii::app()->params->checkMolExec   		= '"'.Yii::app()->params->checkMatchMolDir.'checkmol"';
	Yii::app()->params->matchMolExec   		= '"'.Yii::app()->params->checkMatchMolDir.'matchmol"';
}
//  Batch Script Settings
Yii::app()->params->batchDir            = 'protected/kscreen_lib/batch/';

Yii::app()->params->dataFilePrefix      = 'A';
Yii::app()->params->confFilePrefix      = 'C';

Yii::app()->params->dataFileFormat      = 'csv';
Yii::app()->params->confFileFormat      = 'csv';
Yii::app()->params->permFileFormat		= 'csv';

Yii::app()->params->searchFileFormat	= 'csv';

Yii::app()->params->rBin                = 'Rscript';

//Option Constants
Yii::app()->params->drcFunctions		= array('Brain-Cousens' => 'Brain-Cousens'	, 'Sigmoid' => 'Sigmoid',	'NoFit' => 'No Fit');
Yii::app()->params->drcSummaryVar		= array('Brain-Cousens' => 'hormosis'		, 'Sigmoid' => 'ic50'	,	'NoFit' => '');
Yii::app()->params->drcFunctionDefault	= array('Sigmoid');

Yii::app()->params->molDataNameField 	= 'KUID';

//Secure Fetching
Yii::app()->params->fetchImgExts		= array('bmp','png','jpg','jpeg');
Yii::app()->params->fetchDownloadExts	= array('zip','csv','txt');

//Plate Coordinate System
Yii::app()->params->plateRows			= array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P');
Yii::app()->params->plateNumCols        = 24;

//Plate Coordinate System Generation -- Not Used Anymore
/*Yii::app()->params->plateCols			= array();
for($i = 1; $i <= Yii::app()->params->plateNumCols; $i++)
{
	Yii::app()->params->plateCols[] = $i;
}*/
Yii::app()->params->plateNumRows = count(Yii::app()->params->plateRows); 

//Plate Column RegEx not needed
Yii::app()->params->plateNameRegEx = '^\d+';
Yii::app()->params->plateRowsRegEx = '[A-Pa-p]';

//Spaces are automatically removed so it is not a good idea to have spaces or space separation for chemical names
Yii::app()->params->plateConfRegEx = '[A-Za-z0-9_]+'; // Chemical Name
Yii::app()->params->plateDataRegEx = '-*\d+\.?\d*'; 

return array(
	'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..',
	'name'=>'K-Screen High Throughput Screening Information Management System',
	'defaultController' => 'site/index',
	// preloading 'log' component
	'preload'=>array('log'),

	// autoloading model and component classes

	'import'=>array(
		'application.models.*',
		'application.components.*',
	),
	
	// modules
	
	'modules'=>array(
		'gii'=>array(
			'class'=>'system.gii.GiiModule',
			'password'=>'password',
			'ipFilters'=>array(
				'localhost',
			),
			// 'newFileMode'=>0666,
			// 'newDirMode'=>0777,
		),
	),

	// application components
	'components'=>array(
		'user'=>array(
			// enable cookie-based authentication
			'allowAutoLogin'=>true,
		),
		// uncomment the following to enable URLs in path-format
		'urlManager'=>array(
			'urlFormat'=>'path',
			'rules'=>array(
				'gii'=>'gii',
				'gii/<controller:\w+>'=>'gii/<controller>',
				'gii/<controller:\w+>/<action:\w+>'=>'gii/<controller>/<action>',
				'<controller:\w+>/<id:\d+>'=>'<controller>/view',
				'<controller:\w+>/<action:\w+>/<id:\d+>'=>'<controller>/<action>',
				'<controller:\w+>/<action:\w+>'=>'<controller>/<action>',
			),
		),
		/*'db'=>array(
			'connectionString' => 'sqlite:'.dirname(__FILE__).'/../data/testdrive.db',
		),*/
		// uncomment the following to use a MySQL database
		'db'=>array(
			'connectionString' => 'mysql:host=localhost;dbname=KSCREEN_DATABASE_NAME',
			'emulatePrepare' => true,
			'username' => 'USER',
			'password' => 'PASSWORD',
			'charset' => 'utf8',
		),
		'errorHandler'=>array(
			// use 'site/error' action to display errors
            'errorAction'=>'site/error',
        ),
		'log'=>array(
			'class'=>'CLogRouter',
			'routes'=>array(
				array(
					'class'=>'CFileLogRoute',
					'levels'=>'error, warning',
				),
                array(
                    'class'=>'CProfileLogRoute',
                ),
				// uncomment the following to show log messages on web pages
				/*
				array(
					'class'=>'CWebLogRoute',
				),
				*/
			),
		),
		'zip'=>array(
			'class'=>'application.extensions.zip.EZip',
		),

	),

	// application-level parameters that can be accessed
	// using Yii::app()->params['paramName']
	'params'=>array(
		// this is used in contact page
		'adminEmail'=>'webmaster@example.com',
	),
);