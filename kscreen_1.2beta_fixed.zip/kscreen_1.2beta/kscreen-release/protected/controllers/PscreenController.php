<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# PscreenController.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#
Yii::import('application.kscreen_lib.graph.*');
Yii::import('application.kscreen_lib.parse.*');
require_once('PscreenGrapher.php');
require_once('PscreenPlatePlotter.php');
require_once('PlateParser.php');
require_once('Plate.php');

class PscreenController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column1';

	/**
	 * @var CActiveRecord the currently loaded data model instance.
	 */
	private $_model;

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array(
				'fetch',
				'index',
				'browse',
                'makePscreenBrowser','makePscreenHistogram','makePlateBrowser','makePlateGraph','makeMolView',
                'listSscreens','listPlates',
				'infoLinks',
				'getPscreenMinMax',
                'textSearch','textBatchSearch','funcGroupSearch','localStructSearch','pubChemStructSearch','chemSpiderStructSearch','zincStructSearch',
                'downloadSearchCSV','downloadSearchSDF',
				'venn','scatter',
				),
				'users'=>array('@'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('view','create','update','admin','delete','present','fetchDefaultPlateConf'),
				'users'=>array('@'),
				'expression'=>'isset($user->admin) && ($user->admin==1)',
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}
	
	public function actionFetchDefaultPlateConf()
	{
		try
		{
			header('Content-Type: application/octet-stream; '); 
			header('Content-Disposition: attachment; filename="'.Yii::app()->params->defaultConfFile.'";'); 
			readfile(Yii::app()->params->assetsDir.Yii::app()->params->defaultConfFile);
			exit();
		}
		catch(Exception $e)
		{
			System.out.println($e);
		}
	}
	
	public function actionFetch()
	{
		if(isset($_GET['Pscreen']['id']) && (PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(), $_GET['Pscreen']['id']) 
			|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))))
		{
			$uploadDir = preg_replace('/\%1/',$_GET['Pscreen']['id'],Yii::app()->params->pscreenDataUploadDir);
			if(isset($_GET['file']) && is_file($uploadDir.$_GET['file']))
			{
				$imgExts = Yii::app()->params->fetchImgExts;
				$isImg = false;
				$fileExt = array_pop(preg_split('/\./', $_GET['file']));
				foreach($imgExts as $ext)
				{
					if(strcmp($fileExt,$ext) == 0)
					{
						$isImg = true;
					}
				}
				
				if($isImg)
				{
                    header("Pragma: public"); // required
                    header("Expires: 0");
                    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                    header("Cache-Control: private",false); // required for certain browsers
                    header('Content-Type: image/jpeg');
                    header('Content-Disposition: filename="'.basename($uploadDir.$_GET['file']).'";'); 
                    header("Content-Transfer-Encoding: binary");
                    header('Content-Length: '.filesize($uploadDir.$_GET['file'])); 
					readfile($uploadDir.$_GET['file']);
					exit();
				}
				else
				{
					$downloadExts = Yii::app()->params->fetchDownloadExts;
					$isDownload = false;
					$fileExt = array_pop(preg_split('/\./', $_GET['file']));
					foreach($downloadExts as $ext)
					{
						if(strcmp($fileExt,$ext) == 0)
						{
							$isDownload = true;
						}
					}
					if($isDownload)
					{
						header("Pragma: public");
                        header("Expires: 0");
                        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                        header("Cache-Control: public");
                        header("Content-Description: File Transfer");
                        header("Content-Type: application/octet-stream");
                        header('Content-Disposition: attachment; filename="'.basename($uploadDir.$_GET['file']).'";'); 
                        header("Content-Transfer-Encoding: binary");
                        header('Content-Length: '.filesize($uploadDir.$_GET['file'])); 
						readfile($uploadDir.$_GET['file']);
						exit();
					}
				}
			}
		}
		throw new CHttpException(404,'File Does Not Exist.');
	}

	public function actionInfoLinks()
	{
		if(isset($_POST['Pscreen']['id']) && (PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(), $_POST['Pscreen']['id']) 
			|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))))
		{
			$model = Pscreen::model()->findByPk($_POST['Pscreen']['id']);
			$this->renderPartial('_browseInfo',array(
				'model'=>$model,
			));
		}
	}
	
	/**
	 * Displays a particular model.
	 */
	public function actionView()
	{
		$this->render('view',array(
			'model'=>$this->loadModel(),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model = new Pscreen('create');

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Pscreen']))
		{
            $model->attributes=$_POST['Pscreen'];
            $model->creator_id = Yii::app()->user->getId();
            
			if(isset($_POST['default_conf']) && is_file(Yii::app()->params->defaultConfFileDir))
			{
				$_FILES['Pscreen']['name']['conf_file'] 	= Yii::app()->params->defaultConfFile;
				$_FILES['Pscreen']['tmp_name']['conf_file'] = Yii::app()->params->defaultConfFileDir;
				$_FILES['Pscreen']['error']['conf_file'] 	= 0;
				$_FILES['Pscreen']['size']['conf_file'] 	= filesize(Yii::app()->params->defaultConfFileDir);
			}
		
            $model->confFile=CUploadedFile::getInstance($model,'conf_file');
            $model->dataFile=CUploadedFile::getInstance($model,'data_file');
			$model->permFile=CUploadedFile::getInstance($model,'perm_file');
						                            
   			if($model->save())
            {
				$model->create();
				$this->redirect(array('view','id'=>$model->id));
            }
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionUpdate()
	{
		$model = $this->loadModel();

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Pscreen']))
		{
            $model->attributes=$_POST['Pscreen'];
            $model->creator_id = Yii::app()->user->getId();

			if(isset($_POST['default_conf']) && is_file(Yii::app()->params->defaultConfFileDir))
			{
				$_FILES['Pscreen']['name']['conf_file'] 	= Yii::app()->params->defaultConfFile;
				$_FILES['Pscreen']['tmp_name']['conf_file'] = Yii::app()->params->defaultConfFileDir;
				$_FILES['Pscreen']['error']['conf_file'] 	= 0;
				$_FILES['Pscreen']['size']['conf_file'] 	= filesize(Yii::app()->params->defaultConfFileDir);
			}
				
			$model->confFile=CUploadedFile::getInstance($model,'conf_file');
			$model->dataFile=CUploadedFile::getInstance($model,'data_file');
			$model->permFile=CUploadedFile::getInstance($model,'perm_file');
								
			if($model->create())
			{
				$model->date = date('Y-m-d H:i:s');
				$model->save();                
				$this->redirect(array('view','id'=>$model->id));
			}
			else
			{
				$this->redirect(array('admin'));
			}
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'index' page.
	 */
	public function actionDelete()
	{
		// we only allow deletion via POST request
		$model = $this->loadModel();
		$model->status = 0;
		$model->save();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$this->actionBrowse();
		exit();
		$dataProvider=new CActiveDataProvider('Pscreen');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new Pscreen('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Pscreen']))
			$model->attributes=$_GET['Pscreen'];
		$model->status = 1;

		$this->render('admin',array(
			'model'=>$model,
		));
	}
	
	/**
	 * Browse a Model
	 */
	public function actionBrowse()
	{
        $model = Pscreen::model()->with('pscreenResults')->findByPk(75);
			
        try
        {
            $pscreenModel		    = new Pscreen('browseById');
            $pscreenResultModel     = new PscreenResult('browseByPlate');
            $pscreenPlateList 	    = array();

            if(isset($_POST['Pscreen']['id']) && (PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(), $_POST['Pscreen']['id'])
				|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))))
            {
                $pscreenModel=Pscreen::model()->findByPk($_POST['Pscreen']['id']);
                if(isset($_POST['PscreenResult']['dplate'])  && (PscreenPermission::hasPscreenPlatePermission(Yii::app()->user->getId(), $_POST['Pscreen']['id'], $_POST['PscreenResult']['dplate'])
					|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))))
                {
                    $pscreenPlateList   = $_POST['PscreenResult']['dplate'];
                }
            }
            
            $this->render('browse',array(
                'pscreenModel'          => $pscreenModel,
                'pscreenResultModel'    => $pscreenResultModel,
                'pscreenPlateList'      => $pscreenPlateList,
            ));
        }
        catch(Exception $e)
        {
            print_r($e);
        }
	}
	
	public function actionListSscreens()
	{
		if(isset($_POST['Pscreen']['id']) && (PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(), $_POST['Pscreen']['id']) 
			|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))))
		{
			$data = Sscreen::model()->findAll(
					array(
						'select'	=> 'id,name',
						'condition' => 'pscreen_id = '.$_POST['Pscreen']['id'].' and finalize > 0',
						));
			$listData=CHtml::listData($data,'id','name');
			foreach($listData as $key=>$value)
			{
				echo CHtml::tag('option',
						array(
							'value'     => $key,
						),CHtml::encode($value),false);
			}
		}
	}
	
    public function actionListPlates()
	{
        try
        {
            if(isset($_POST['Pscreen']['id']) && (PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(), $_POST['Pscreen']['id'])
                || (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))))
            {
                $model = Pscreen::model()->findByPk($_POST['Pscreen']['id']);
                $permissions = array();
                if(isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))
                {
                    $permissions = PscreenPermission::getPscreenPlatePermissions($_POST['Pscreen']['id']);
                }
                else
                {
                    $permissions = PscreenPermission::getPscreenPlatePermissions(Yii::app()->user->getId(), $_POST['Pscreen']['id']);
                }
                
                if($permissions)
                {
                    $data = PscreenResult::model()->findAll(
                            array( 
                                'select'	=> 'dplate',
                                'condition' => 'pscreen_id = '.$_POST['Pscreen']['id'].' and dplate in ('.join(',',$permissions).') and '.$model->normalization.' IS NOT NULL',
                                'order'		=> 'ABS(dplate)',
                                'group'		=> 'dplate',
                                ));
             
                    $listData=CHtml::listData($data,'dplate','dplate');
                    foreach($listData as $key=>$value)
                    {
                        echo CHtml::tag('option',
                                array(
                                    'value'     => $key,
                                    'selected'  => 'true'
                                ),CHtml::encode($value),true);
                    }
                }
            }
        }
        catch(Exception $e)
        {
            print_r($e);
        }
	}
    
	public function actionPresent()
    {
        $model              = $this->loadModel();
        $plates             = $model->procData;
        $defaultCheckBox    = array();
        $defaultCheckBoxAlt = array();
        $useCheckBoxAlt     = true;
        
		if(isset($_POST['Pscreen']['finalize']) && $model->status != 2 && isset($_POST['Pscreen']['normalization']))
        {
            $model->normalization = $_POST['Pscreen']['normalization'];
            
            $plates = array();
            $logging = array();
            
            if(isset($_POST['Plates']))
            {	
				$plates = $_POST['Plates'];
                $logging[0]['type'] = 1;
                $logging[0]['data'] = "Presentation Update Failed.";
            }
            else
            {
                $logging[0]['type'] = 0;
                $logging[0]['data'] = "Nothing to Update.";
            }
			
            if($model->save())
            {
				try
				{
					$logging = $model->procResults($plates);
				}
				catch(Exception $e)
				{
					var_dump($e->getMessage());
				}
				
                $model->finalize = $_POST['Pscreen']['finalize'];
                if($model->save())
                {
                    $logging[] = array(
                        'type' => 0,
                        'data' => "Finalized Uploads...",
                    );
                }
            }
            $this->render('presentUploadResults',array(
                'model'=>$model,
                'logging'=>$logging,
            ));
        }
		else if ( $model->status == 2 )
		{
			$logging = array();
            
            $logging[0]['type'] = 2;
            $logging[0]['data'] = "WARNING: You have been locked out of this project as it is being modified.  Please try back later.";
			
			$this->render('presentUploadResults',array(
                'model'=>$model,
                'logging'=>$logging,
            ));
		}
        else
        {
            foreach($plates as $plate => $plateData)
            {
                $result = PscreenResult::model()->findByAttributes( array('dplate' => $plate, 'pscreen_id' => $model->id ));
                if(isset($result))
                {
                    $defaultCheckBox[$plate]    = true;
                    $useCheckBoxAlt             = false;
                }
                else
                {
                    $defaultCheckBox[$plate]    = false;
                    $defaultCheckBoxAlt[$plate] = true;
                }
                if($useCheckBoxAlt)
                {
                    $defaultCheckBox = $defaultCheckBoxAlt;
                }
            }
            $this->render('present',array(
                'model'=>$model,
                'plates'=>$plates,
                'checked'=>$defaultCheckBox,
            ));
        }
	}
    
    public function actionMakePscreenBrowser()
    {
		if(!isset($_POST['PscreenResult']['dplate']) || count($_POST['PscreenResult']['dplate']) == 0)
		{
			exit();
		}
 		else if(isset($_POST['Pscreen']['id']) && isset($_POST['PscreenResult']['dplate'])  && (PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(),$_POST['Pscreen']['id'])
			|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))))
            {
			$permissions = array();
			if(isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))
			{
				$permissions = PscreenPermission::getPscreenPlatePermissions($_POST['Pscreen']['id']);
			}
			else
			{
				$permissions = PscreenPermission::getPscreenPlatePermissions(Yii::app()->user->getId(), $_POST['Pscreen']['id']);
			}
			
			$pscreenModel   = Pscreen::model()->findByPk($_POST['Pscreen']['id']);
			
			$pscreenPlateList       = array_intersect($_POST['PscreenResult']['dplate'], $permissions);
			$pscreenPlateStatsList  = $pscreenModel->calcStatistics($pscreenPlateList);
			
			$pscreenBrowserName     = 'pscreen_browser_'.md5(gettimeofday(TRUE)).'.png';
			
			$pscreenBrowser         = new PscreenGrapher($pscreenModel->name, $_POST['Pscreen']['id'], max(910,100+20*count($pscreenPlateStatsList)), 300);
			$pscreenBrowser->graphBrowser($pscreenPlateStatsList, Yii::app()->params->tempDir.$pscreenBrowserName);

			echo CHtml::tag('img',
					array(
						'src' => Yii::app()->request->baseUrl.'/'.Yii::app()->params->tempDir.$pscreenBrowserName,
						'alt' => 'Primary Screen '.$pscreenModel->name,
						'usemap' => '#PscreenBrowserMap',
					));
			return;
        }
        echo 'No Primary Screen Loaded';
    }
	
    public function actionMakePscreenHistogram()
    {
		if(!isset($_POST['PscreenResult']['dplate']) || count($_POST['PscreenResult']['dplate']) == 0)
		{
			exit();
		}
 		else if(isset($_POST['Pscreen']['id']) && isset($_POST['PscreenResult']['dplate']) && (PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(),$_POST['Pscreen']['id'])
			|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))))
            {
			$permissions = array();
			if(isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))
			{
				$permissions = PscreenPermission::getPscreenPlatePermissions($_POST['Pscreen']['id']);
			}
			else
			{
				$permissions = PscreenPermission::getPscreenPlatePermissions(Yii::app()->user->getId(), $_POST['Pscreen']['id']);
			}
			
			$pscreenModel   = Pscreen::model()->findByPk($_POST['Pscreen']['id']);
			
			$pscreenPlateList   = array_intersect($_POST['PscreenResult']['dplate'], $permissions);
			$pscreenBins        = $pscreenModel->calcBins($pscreenPlateList);
			
			$pscreenHistogramName = 'pscreen_histogram_'.md5(gettimeofday(TRUE)).'.png';
			
			$pscreenHistogram = new PscreenGrapher($pscreenModel->name,$_POST['Pscreen']['id'] , 420, 400);
			$pscreenHistogram->graphHistogram($pscreenBins, Yii::app()->params->tempDir.$pscreenHistogramName);
			
			echo CHtml::tag('img',
					array(
						'src' => Yii::app()->request->baseUrl.'/'.Yii::app()->params->tempDir.$pscreenHistogramName,
						'alt' => 'Primary Screen '.$pscreenModel->name,
					));
			return;
        }
        echo 'No Primary Screen Loaded';
    }
    
    public function actionMakePlateBrowser()
    {
		if(!isset($_POST['PscreenResult']['dplate']) || count($_POST['PscreenResult']['dplate']) == 0)
		{
			exit();
		}
        else if(isset($_POST['Pscreen']['id']) && isset($_POST['PscreenResult']['dplate'][0]) && ((PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(),$_POST['Pscreen']['id']) && PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(),$_POST['Pscreen']['id'],$_POST['PscreenResult']['dplate'][0]))
			|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))))
		{
			$pscreenModel   = Pscreen::model()->findByPk($_POST['Pscreen']['id']);
			$pscreenPlate   = $_POST['PscreenResult']['dplate'][0];
			$plateData      = $pscreenModel->getPlate($pscreenPlate);

			$pscreenTable = new PscreenPlatePlotter($pscreenPlate, $_POST['Pscreen']['id'], Yii::app()->request->baseUrl.'/images/',Yii::app()->params->plateRows,Yii::app()->params->plateNumCols);
			echo $pscreenTable->plotPlate($plateData); 
		}
        else
        {
            echo 'No Plate Loaded';
        }
    }
	
	public function actionMakeMolView()
    {
		if(!isset($_POST['PscreenResult']['dplate']) || count($_POST['PscreenResult']['dplate']) == 0)
		{
			exit();
		}
        else if(isset($_POST['Pscreen']['id']) && isset($_POST['PscreenResult']['dplate'][0]) && isset($_POST['PscreenResult']['drow']) && isset($_POST['PscreenResult']['dcol']) && (PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(),$_POST['Pscreen']['id'])
		|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))))
		{
			$pscreenPlateList;
			if(isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))
			{
				$pscreenPlateList	= array_intersect($_POST['PscreenResult']['dplate'],PscreenPermission::getPscreenPlatePermissions($_POST['Pscreen']['id']));
			}
			else
			{
				$pscreenPlateList   = array_intersect($_POST['PscreenResult']['dplate'],PscreenPermission::getPscreenPlatePermissions(Yii::app()->user->getId(), $_POST['Pscreen']['id']));
			}
			$pscreenModel   	= Pscreen::model()->findByPk($_POST['Pscreen']['id']);
			$pscreenResultModel = PscreenResult::model()->with('mol')->findByAttributes(array('pscreen_id' => $_POST['Pscreen']['id'], 'dplate'=>$pscreenPlateList,'drow'=>$_POST['PscreenResult']['drow'],'dcol'=>$_POST['PscreenResult']['dcol']));
			if(isset($pscreenResultModel))
			{
				
				$this->renderPartial( '_molView', array(
					'pscreenResultModel'          => $pscreenResultModel,
				)); 
				return;
			}
        }    
		echo 'No Molecule Loaded';
	}
    
    public function actionMakePlateGraph()
    {
		try{
		if(!isset($_POST['PscreenResult']['dplate']) || count($_POST['PscreenResult']['dplate']) == 0)
		{
			exit();
		}
        else if(isset($_POST['Pscreen']['id']) && isset($_POST['PscreenResult']['dplate']) && isset($_POST['PscreenResult']['dplate'][0]) && ((PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(),$_POST['Pscreen']['id']) && PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(),$_POST['Pscreen']['id'],$_POST['PscreenResult']['dplate'][0])))
			|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1)))
		{
			$pscreenModel   = Pscreen::model()->findByPk($_POST['Pscreen']['id']);
			$pscreenPlate   = $_POST['PscreenResult']['dplate'][0];
			$selectedPoint = false;
			if(isset($_POST['PscreenResult']['drow']) && isset($_POST['PscreenResult']['dcol']))
			{
				$selectedPoint = array('row' => $_POST['PscreenResult']['drow'], 'col' => $_POST['PscreenResult']['dcol']);
			}
			$plateData      = $pscreenModel->getPlate($pscreenPlate);
			
			$pscreenPlateName   = 'pscreen_plate_'.md5(gettimeofday(TRUE)).'.png';
			
			$pscreenPlateGraph  = new PscreenGrapher($pscreenPlate, $_POST['Pscreen']['id'], 600, 240);
			$pscreenPlateGraph->graphPlate($plateData, Yii::app()->params->tempDir.$pscreenPlateName, Yii::app()->params->plateRows, $selectedPoint);
			
			echo CHtml::tag('img',
					array(
						'src' => Yii::app()->request->baseUrl.'/'.Yii::app()->params->tempDir.$pscreenPlateName,
						'alt' => 'Plate '.$pscreenPlate,
						'usemap' => '#PscreenPlateGraphMap',
					));
			return;
        }
        echo 'No Plate Loaded';
		}
		catch(Exception $e)
		{
			print_r($e);
		}
    }
    
    public function actionTextSearch()
    {
	try
	{
		$molDataModel 		= new MolData();
		$pscreenResultModel = new PscreenResult();
		
        $key = false;
        foreach($_GET as $k => $v)
        {
            if(preg_match('/^'.Yii::app()->params->searchCacheFilePrefix.'/', $k))
            {
                $key = $k;
            }
        }
        
		if(!$key && isset($_POST['search']['input']['MolData']) && isset($_POST['search']['input']['PscreenResult']) && isset($_POST['search']['settings']))
		{
            $searchKey      = preg_replace('/\./','_',Yii::app()->params->searchCacheFilePrefix.gettimeofday(TRUE));
			$searchResults  = Pscreen::performTextSearch($_POST['search']['input']['MolData'], $_POST['search']['input']['PscreenResult'], $_POST['search']['settings'], $searchKey);
            $this->render('searchResults',array(
                'dataProvider'=>$searchResults[0],
                'cols'=>$searchResults[1],
                'msg'=>$searchResults[2],
                'key'=>$searchKey,
            )); 
            return;
		}
        else if($key)
        {
            $searchResults  = Pscreen::loadSearch($key);
            if($searchResults)
            {
                $this->render('searchResults',array(
                    'dataProvider'=>$searchResults[0],
                    'cols'=>$searchResults[1],
                    'msg'=>$searchResults[2],
                    'key'=>$key,
                ));
            }
            else
            {
                echo 'Search Key "'.$key.'" Invalid, Please Re-run This Search.';
            }
            return;
        }
		
        $this->render('searchText',array(
			'molDataModel' 			=> $molDataModel, 
			'pscreenResultModel'	=> $pscreenResultModel
		));
	}
	catch(Exception $e)
	{
		print_r($e);
	}
    }
    
    public function actionTextBatchSearch()
    {
		$molDataModel 		= new MolData();
		$pscreenResultModel = new PscreenResult();
		
        $key = false;
        foreach($_GET as $k => $v)
        {
            if(preg_match('/^'.Yii::app()->params->searchCacheFilePrefix.'/', $k))
            {
                $key = $k;
            }
        }
		       
		if(!$key && isset($_POST['search']['input']['MolData']) && isset($_POST['search']['input']['PscreenResult']) && isset($_POST['search']['settings']))
		{
			$pscreenModel = new Pscreen();
			$pscreenModel->batchSearchMolFile=CUploadedFile::getInstance($pscreenModel,'batchSearchMolFile');
			$pscreenModel->batchSearchMIDFile=CUploadedFile::getInstance($pscreenModel,'batchSearchMIDFile');
			$pscreenModel->batchSearchDIDFile=CUploadedFile::getInstance($pscreenModel,'batchSearchDIDFile');
			
            $searchKey      = preg_replace('/\./','_',Yii::app()->params->searchCacheFilePrefix.gettimeofday(TRUE));
			$searchResults  = $pscreenModel->performTextBatchSearch($_POST['search']['input']['MolData'], $_POST['search']['input']['PscreenResult'], $_POST['search']['settings'], $searchKey);
            $this->render('searchResults',array(
                'dataProvider'=>$searchResults[0],
                'cols'=>$searchResults[1],
                'msg'=>$searchResults[2],
                'key'=>$searchKey,
            )); 
            return;
		}
        else if($key)
        {
            $searchResults  = Pscreen::loadSearch($key);
            if($searchResults)
            {
                $this->render('searchResults',array(
                    'dataProvider'=>$searchResults[0],
                    'cols'=>$searchResults[1],
                    'msg'=>$searchResults[2],
                    'key'=>$key,
                ));
            }
            else
            {
                echo 'Search Key "'.$key.'" Invalid, Please Re-run This Search.';
            }
            return;
        }
		
        $this->render('searchTextBatch',array(
			'molDataModel' 			=> $molDataModel, 
			'pscreenResultModel'	=> $pscreenResultModel
		));
    }
	
	public function actionFuncGroupSearch()
    {
		try{
		$molFuncGroupModel	= new MolFuncGroup();
		
        $key = false;
        foreach($_GET as $k => $v)
        {
            if(preg_match('/^'.Yii::app()->params->searchCacheFilePrefix.'/', $k))
            {
                $key = $k;
            }
        }
        
		if(!$key && isset($_POST['MolFuncGroup']['fgbit']) && isset($_POST['search']['settings']))
		{
            $searchKey      = preg_replace('/\./','_',Yii::app()->params->searchCacheFilePrefix.gettimeofday(TRUE));
            $searchResults  = Pscreen::performFuncGroupSearch($_POST['MolFuncGroup']['fgbit'], $_POST['search']['settings'], $searchKey);
            $this->render('searchResults',array(
                'dataProvider'=>$searchResults[0],
                'cols'=>$searchResults[1],
                'msg'=>$searchResults[2],
                'key'=>$searchKey,
            ));
            return;
		}
        else if($key)
        {
            $searchResults  = Pscreen::loadSearch($key);
            if($searchResults)
            {
                $this->render('searchResults',array(
                    'dataProvider'=>$searchResults[0],
                    'cols'=>$searchResults[1],
                    'msg'=>$searchResults[2],
                    'key'=>$key,
                ));
            }
            else
            {
                echo 'Search Key "'.$key.'" Invalid, Please Re-run This Search.';
            }
            return;
        }
		
        $this->render('searchFuncGroup',array(
			'molFuncGroupModel' => $molFuncGroupModel, 
		));
		}catch(Exception $e)
		{
			print_r($e);
		}
    }
    
    public function actionLocalStructSearch()
    {
        $jmeData = '';
        if(isset($_POST['search']['input']['jme']))
        {
            $jmeData = $_POST['search']['input']['jme'];
        }
        
        $key = false;
        foreach($_GET as $k => $v)
        {
            if(preg_match('/^'.Yii::app()->params->searchCacheFilePrefix.'/', $k))
            {
                $key = $k;
            }
        }
        
		if(!$key && isset($_POST['search']['input']['mode']) && isset($_POST['search']['input']['jme']) && isset($_POST['search']['input']['mol']) && isset($_POST['search']['input']['smiles']) && isset($_POST['search']['settings']))
		{
            $searchKey      = preg_replace('/\./','_',Yii::app()->params->searchCacheFilePrefix.gettimeofday(TRUE));
            $searchResults  = Pscreen::performLocalStructSearch($_POST['search']['input'], $_POST['search']['settings'], $searchKey);
			if($searchResults === false)
			{
				return;
			}
            $this->render('searchResults',array(
                'dataProvider'=>$searchResults[0],
                'cols'=>$searchResults[1],
                'msg'=>$searchResults[2],
                'key'=>$searchKey,
            ));
            return;
		}
        else if($key)
        {
            $searchResults  = Pscreen::loadSearch($key);
            if($searchResults)
            {
                $this->render('searchResults',array(
                    'dataProvider'=>$searchResults[0],
                    'cols'=>$searchResults[1],
                    'msg'=>$searchResults[2],
                    'key'=>$key,
                ));
            }
            else
            {
                echo 'Search Key "'.$key.'" Invalid, Please Re-run This Search.';
            }
            return;
        }
		
        $this->render('searchLocalStruct',array(
            'jmeData'         => $jmeData,
		));
    }
	
	public function actionPubChemStructSearch()
    {
		try
		{
        $jmeData = '';
        if(isset($_POST['search']['input']['jme']))
        {
            $jmeData = $_POST['search']['input']['jme'];
        }
        	
        $this->render('searchPubChemStruct',array(
            'jmeData'         => $jmeData,
		));
		}catch(Exception $e)
		{
			print_r($e);
		}
    }
	
	public function actionChemSpiderStructSearch()
    {
		try
		{
        $jmeData = '';
        if(isset($_POST['search']['input']['jme']))
        {
            $jmeData = $_POST['search']['input']['jme'];
        }
        	
        $this->render('searchChemSpiderStruct',array(
            'jmeData'         => $jmeData,
		));
		}catch(Exception $e)
		{
			print_r($e);
		}
    }
	
	public function actionZincStructSearch()
    {
		try
		{
        $jmeData = '';
        if(isset($_POST['search']['input']['jme']))
        {
            $jmeData = $_POST['search']['input']['jme'];
        }
        	
        $this->render('searchZincStruct',array(
            'jmeData'         => $jmeData,
		));
		}catch(Exception $e)
		{
			print_r($e);
		}
    }
    
    public function actionDownloadSearchCSV()
    {    
		if(isset($_GET['searchKey']))
		{
			header('Content-Type: application/octet-stream; '); 
			header('Content-Disposition: attachment; filename="'.$_GET['searchKey'].'.csv";'); 
			echo Pscreen::downloadSearchCSV($_GET['searchKey']);
		}
    }
	
	public function actionDownloadSearchSDF()
    {        
		if(isset($_GET['searchKey']))
		{
			header('Content-Type: application/octet-stream; '); 
			header('Content-Disposition: attachment; filename="'.$_GET['searchKey'].'.sdf";'); 
			echo Pscreen::downloadSearchSDF($_GET['searchKey']);
		}
    }
		 
	public function actionGetPscreenMinMax()
	{
		if(isset($_POST['search']['settings']))
		{
			foreach($_POST['search']['settings'] as $pscreen)
			{
				if(isset($pscreen['id']))
				{
					$pscreenModelRef = Pscreen::model()->findbyPk($pscreen['id']);
					$norm = ucfirst($pscreenModelRef->normalization);
					$pscreenModel = Pscreen::model()->with('minPscreenResult'.$norm, 'maxPscreenResult'.$norm)->findbyPk($pscreen['id']);
					if(isset($pscreenModel))
					{
						echo $pscreenModel['minPscreenResult'.$norm].' '.$pscreenModel['maxPscreenResult'.$norm];
						return;
					}
				}
			}
		}
		echo '0 0';
	}
	
	public function actionVenn()
	{
		if(isset($_POST['search']['settings']))
		{
           	$searchResults  = Pscreen::performVennCompare($_POST['search']['settings']);
            $this->render('vennResult',array(
                'setResults'=>$searchResults,
            )); 
            return;
		}
		
		$this->render('venn',array(
		));
	}
	
	public function actionScatter()
	{
		if(isset($_POST['search']['settings']))
		{
           	$searchResults  = Pscreen::getDataScatter($_POST['search']['settings']);
			
			$scatterName     	= 'scatter_'.md5(gettimeofday(TRUE)).'.png';
			
			$pscreenGrapher  	= new PscreenGrapher('Intersection', 'ScatterGram', 600, 600);
			$scatterMap 		= $pscreenGrapher->graphScatter($searchResults, Yii::app()->params->tempDir.$scatterName);
            $this->render('scatterResult',array(
				'src' => Yii::app()->request->baseUrl.'/'.Yii::app()->params->tempDir.$scatterName,
				'alt' => 'Scattergram',
				'map' => $scatterMap ,
				'usemap' => '#ScatterMap',
            )); 
            return;
		}
		
		$this->render('scatter',array(
		));
	}
	 
    /**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 */
	public function loadModel()
	{
		if($this->_model===null)
		{
			if(isset($_GET['id']))
				$this->_model=Pscreen::model()->findbyPk($_GET['id']);
			if($this->_model===null)
				throw new CHttpException(404,'The requested page does not exist.');
		}
		return $this->_model;
	}
	
	/**
	 * Performs the AJAX validation.
	 * @param CModel the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='pscreen-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}