<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# SscreenAttachmentController.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#

class SscreenAttachmentController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column1';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','download'),
				'users'=>array('@'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','admin','delete'),
				'users'=>array('@'),
				'expression'=>'isset($user->admin) && ($user->admin==1)',
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		if(isset($_GET['Sscreen']['id']))
		{
			$model = Sscreen::model()->findByPk($_GET['Sscreen']['id']);
			if((PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(), $model->pscreen_id) || isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1)))
			{
				$this->render('view',array(
					'model'=>$this->loadModel($id),
				));
			}
		}
		else
		{
			throw new CHttpException(403,'You do not have permission to access this screen.');
		}
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new SscreenAttachment('create');

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
		if(isset($_GET['Sscreen']['id']))
		{
			$sscreenModel = Sscreen::model()->findByPk($_GET['Sscreen']['id']);
		}
		if(isset($sscreenModel))
		{
			$model->sscreen_id=$_GET['Sscreen']['id'];
		}
		else
		{
			throw new CHttpException(404,'The screen specified does not exist.');
		}

		if(isset($_POST['SscreenAttachment']))
		{
			$model->attributes=$_POST['SscreenAttachment'];
			$model->attachment=CUploadedFile::getInstance($model,'attachment');
			$model->file_name=$model->attachment->name;
			$model->file_data=file_get_contents($model->attachment->tempName);			
			
			if($model->save())
				$this->redirect(array('admin','Sscreen[id]'=>$model->sscreen_id));
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}
	
	public function actionDownload($id)
	{
		if(isset($_GET['Sscreen']['id']))
		{
			$model = Sscreen::model()->findByPk($_GET['Sscreen']['id']);
			if((PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(), $model->pscreen_id) || isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1)))
			{
				$model=$this->loadModel($id);
				if($model !== null)
				{
					header('Content-Type: application/octet-stream; '); 
					header('Content-Disposition: attachment; filename="'.$model->file_name.'";'); 
					echo $model->file_data;
					exit();
				}
			}
		}
		throw new CHttpException(403,'You do not have permission to access this screen.');
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'index' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		if(Yii::app()->request->isPostRequest)
		{
			// we only allow deletion via POST request
			$this->loadModel($id)->delete();

			// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
			if(!isset($_GET['ajax']))
				$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
		}
		else
			throw new CHttpException(400,'Invalid request. Please do not repeat this request again.');
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		try{
		$model=new SscreenAttachment('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['SscreenAttachment']))
		{
			$model->attributes=$_GET['SscreenAttachment'];
		}
		
		$allowed = true;
		
		unset($model->sscreen_id);
		if(isset($_GET['Sscreen']['id']))
		{
			$model2 = Sscreen::model()->findByPk($_GET['Sscreen']['id']);
			if((PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(), $model2->pscreen_id) || isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1)))
			{
				$model->sscreen_id=$_GET['Sscreen']['id'];
			}
			else
			{
				$allowed = false;
			}
		}
		else
		{
			$allowed = false;
		}
		
		if(!$allowed)
		{
			throw new CHttpException(403,'You do not have permission to access this screen.');
		}

		$this->render('index',array(
			'model'=>$model,
		));
		}
		catch(Exception $e)
		{
			print_r($e);
		}
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new SscreenAttachment('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['SscreenAttachment']))
		{
			$model->attributes=$_GET['SscreenAttachment'];
		}
		
		unset($model->sscreen_id);
		$sscreenModel;
		if(isset($_GET['Sscreen']['id']))
		{
			$sscreenModel = Sscreen::model()->findByPk($_GET['Sscreen']['id']);
		}
		if(isset($sscreenModel))
		{
			$model->sscreen_id=$_GET['Sscreen']['id'];
		}
		else
		{
			throw new CHttpException(404,'The screen specified does not exist.');
		}

		$this->render('admin',array(
			'model'=>$model,
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer the ID of the model to be loaded
	 */
	public function loadModel($id)
	{
		$model=SscreenAttachment::model()->findByPk((int)$id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param CModel the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='sscreen-attachment-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
