<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# SscreenController.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#
Yii::import('application.kscreen_lib.graph.*');
require_once('SscreenGrapher.php');

class SscreenController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column1';

	/**
	 * @var CActiveRecord the currently loaded data model instance.
	 */
	private $_model;

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
            array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('fetch','index','browse','listMolData','makeBrowseSscreenCurve'),
                'users'=>array('@'),
            ),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array(
                    'view',
                    'create','update','admin','delete','present',
                    'makeSscreenCurveFromFile', 'makeSscreenCurveFromEditor', 'makeSpecificSscreenCurveFromFile', 'makeRefitSscreenCurveFromEditor',
                    'editorChangeFunction', 'editorChangeCurve', 'editorRefitCurve', 'editorSaveCurve'
                ),
				'users'=>array('@'),
				'expression'=>'isset($user->admin) && ($user->admin==1)',
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}
	
	public function actionFetch()
	{
		if(isset($_GET['Pscreen']['id']) && PscreenPermission::hasPscreenPermission(Yii::app()->user->getId(), $_GET['Pscreen']['id']) 
			|| (isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1)))
		{
			if(isset($_GET['Sscreen']['id']))
			{
				$uploadDir = preg_replace('/\%1/',$_GET['Pscreen']['id'],Yii::app()->params->sscreenDataUploadDir);
				$uploadDir = preg_replace('/\%2/',$_GET['Sscreen']['id'],$uploadDir);

				if(isset($_GET['file']) && is_file($uploadDir.$_GET['file']))
				{
					$imgExts = Yii::app()->params->fetchImgExts;
					$isImg = false;
					$fileExt = array_pop(preg_split('/\./', $_GET['file']));
					foreach($imgExts as $ext)
					{
						if(strcmp($fileExt,$ext) == 0)
						{
							$isImg = true;
						}
					}
					if($isImg)
					{
						header("Pragma: public"); // required
                        header("Expires: 0");
                        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                        header("Cache-Control: private",false); // required for certain browsers
                        header('Content-Type: image/jpeg');
                        header('Content-Disposition: filename="'.basename($uploadDir.$_GET['file']).'";'); 
                        header("Content-Transfer-Encoding: binary");
                        header('Content-Length: '.filesize($uploadDir.$_GET['file'])); 
                        readfile($uploadDir.$_GET['file']);
						exit();
					}
					else
					{
						$downloadExts = Yii::app()->params->fetchDownloadExts;
						$isDownload = false;
						$fileExt = array_pop(preg_split('/\./', $_GET['file']));
						foreach($downloadExts as $ext)
						{
							if(strcmp($fileExt,$ext) == 0)
							{
								$isDownload = true;
							}
						}
						if($isDownload)
						{
							header("Pragma: public");
                            header("Expires: 0");
                            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                            header("Content-Description: File Transfer");
                            header("Content-Type: application/zip");
                            header('Content-Disposition: attachment; filename="'.basename($uploadDir.$_GET['file']).'";'); 
                            header("Content-Transfer-Encoding: binary");
                            header('Content-Length: '.filesize($uploadDir.$_GET['file'])); 
							readfile($uploadDir.$_GET['file']);
							exit();
						}
					}
				}
			}
		}
		throw new CHttpException(404,'File Does Not Exist.');
	}
	
	/**
	 * Displays a particular model.
	 */
	public function actionView()
	{
		$this->render('view',array(
			'model'=>$this->loadModel(),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model = new Sscreen('create');

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Sscreen']))
		{
            $model->attributes=$_POST['Sscreen'];
            $model->creator_id = Yii::app()->user->getId();
            
            $model->confFile=CUploadedFile::getInstance($model,'conf_file');
            $model->dataFile=CUploadedFile::getInstance($model,'data_file');
                            
   			if($model->save())
            {               
                $model->create();
				$this->redirect(array('view','id'=>$model->id));
            }
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionUpdate()
	{
		$model=$this->loadModel();
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Sscreen']))
		{
            $model->attributes=$_POST['Sscreen'];
            $model->creator_id = Yii::app()->user->getId();

			$model->confFile=CUploadedFile::getInstance($model,'conf_file');
			$model->dataFile=CUploadedFile::getInstance($model,'data_file');
								
			if($model->save())
			{               
				$model->create();                
				$this->redirect(array('admin'));
			}
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'index' page.
	 */
	public function actionDelete()
	{
		// we only allow deletion via POST request
		$model = $this->loadModel();
		$model->status = 0;
		$model->save();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$this->actionBrowse();
		exit();
		$dataProvider=new CActiveDataProvider('Sscreen');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new Sscreen('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Sscreen']))
			$model->attributes=$_GET['Sscreen'];
		$model->status=1;

		$this->render('admin',array(
			'model'=>$model,
		));
	}
	
	/**
	 * Browse a Model
	 */
	public function actionBrowse()
	{
		$pscreenModel		    = new Pscreen('browseById');
		$sscreenModel		    = new Sscreen('browseById');
        $sscreenCurveModel		= new SscreenCurve('browseById');
		$sscreenResultModel     = new SscreenResult('browseByMol');

		$this->render('browse',array(
			'pscreenModel'          => $pscreenModel,
			'sscreenModel'          => $sscreenModel,
			'sscreenResultModel'    => $sscreenResultModel,
            'sscreenCurveModel'     => $sscreenCurveModel,
		));
	}
	
	public function actionPresent()
    {
        $model              = $this->loadModel();
        $curves           	= $model->procData;
        $defaultCheckBox    = array();
        $defaultCheckBoxAlt = array();
        $useCheckBoxAlt     = true;     
        
        if(isset($_POST['Sscreen']['finalize']))
        {
            $model->finalize = 0;
        
            $curves = $_POST['curves'];
            $logging = array();
            
            if(isset($curves))
            {
                $logging[0]['type'] = 1;
                $logging[0]['data'] = "Presentation Update Failed.";
            }
            else
            {
                $logging[0]['type'] = 0;
                $logging[0]['data'] = "Nothing to Update.";
            }
            
            if($model->save())
            {
                $logging = $model->procResults($curves);
                $model->finalize = $_POST['Sscreen']['finalize'];
                if($model->save())
                {
                    $logging[] = array(
                        'type' => 0,
                        'data' => "Finalized Uploads...",
                    );
                }
            }
            $this->render('presentUploadResults',array(
                'model'=>$model,
                'logging'=>$logging,
            ));
        }
        else
        {
            foreach($curves as $mol => $curveData)
            {
                $result = SscreenResult::model()->findByAttributes( array('mol_id' => $mol, 'sscreen_id' => $model->id ));
                if(isset($result))
                {
                    $defaultCheckBox[$mol]    = true;
                    $useCheckBoxAlt           = false;
                }
                else
                {
                    $defaultCheckBox[$mol]    = false;
                    $defaultCheckBoxAlt[$mol] = true;
                }
                if($useCheckBoxAlt)
                {
                    $defaultCheckBox = $defaultCheckBoxAlt;
                }
            }
            $this->render('present',array(
                'model'=>$model,
                'curves'=>$curves,
                'checked'=>$defaultCheckBox,
            ));
        }
	}
    
    public function actionListMolData()
    {
		if(isset($_POST['Sscreen']['id']))
		{
			$model = Sscreen::model()->findbyPk($_POST['Sscreen']['id']);
			//$mol_ids = PscreenPermission::getMolDataPermissions(Yii::app()->user->getId(), $model->pscreen_id);
			/*$criteria = new CDbCriteria;
			$criteria->compare('sscreen_id',$_POST['Sscreen']['id']);
			$criteria->addInCondition('mol_id',$mol_ids);*/
			$data = SscreenCurve::model()->with('mol')->findAllByAttributes(array('sscreen_id'=>$_POST['Sscreen']['id']));//$criteria);
			$molIDs = array();
			foreach($data as $item)
			{
				$molIDs[$item->mol_id] = $item->id;
			}
			$validIDs;
			if(isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))
			{
				$validIDs = PscreenPermission::hasMolDataPermissions($model->pscreen_id, $molIDs);
			}
			else
			{
				$validIDs = PscreenPermission::hasMolDataPermissions(Yii::app()->user->getId(), $model->pscreen_id, $molIDs);
			}
			$listData=CHtml::listData($data,'id','mol.name');
			foreach($listData as $key=>$value)
			{
				if(isset($validIDs[$key]))
				{
					echo CHtml::tag('option',
							array(
								'value'     => $key,
							),CHtml::encode($value),false);
				}
			}
		}		
    }
    
    public function actionMakeBrowseSscreenCurve()
    {
		try
		{
 		if(isset($_POST['SscreenCurve']))
		{
            $sscreenCurveModel	= SscreenCurve::model()->with('sscreen', 'mol')->findByPk($_POST['SscreenCurve']['id']);
			if(isset($sscreenCurveModel))
			{
				$sscreenModel = $sscreenCurveModel->sscreen;
				$file = $file = $sscreenModel->dataUploadDir.$sscreenCurveModel->mol->name.'.'.Yii::app()->params->dataFileFormat;
				$id;
				if(isset(Yii::app()->user->admin) && (Yii::app()->user->admin==1))
				{
					$id = PscreenPermission::hasMolDataPermissions($sscreenModel->pscreen_id, array($sscreenCurveModel->mol_id => $sscreenCurveModel->mol_id));
				}
				else
				{
					$id = PscreenPermission::hasMolDataPermissions(Yii::app()->user->getId(), $sscreenModel->pscreen_id, array($sscreenCurveModel->mol_id => $sscreenCurveModel->mol_id));
				}
				if(((isset($user->admin) && ($user->admin==1)) || count($id) > 0))
				{
					$sscreenCurveData           = $sscreenCurveModel->curveData;
					$sscreenCurveBrowserName 	= 'sscreen_curve_graph_'.md5(gettimeofday(TRUE)).'.png';
					$title 						= 'Secondary Screen '.$sscreenCurveModel->mol->name.' for '.$sscreenCurveModel->sscreen->name;
					$sscreenCurveBrowser		= new SscreenGrapher($title, $sscreenCurveModel->sscreen->id, 600, 600);
					$sscreenCurveBrowser->graphDoseResponseCurve($sscreenCurveData, Yii::app()->params->tempDir.$sscreenCurveBrowserName);
					$stats = $sscreenModel->getCurveClassification($sscreenCurveData);//$sscreenModel->getSpecificCurveDataFromFile($sscreenCurveData['func'],$sscreenCurveModel->mol_id,$file));
					
					$molStructData = '';
					if(isset($sscreenCurveModel->mol->molStruct->struc))
					{
						$struct = str_replace("\n",'|',$sscreenCurveModel->mol->molStruct->struc);
						$molStructData = '
<object id="jmolApplet0" width="200" height="150" type="application/x-java-applet" name="jmolApplet0">
	<param value="true" name="progressbar">
	<param value="blue" name="progresscolor">
	<param value="black" name="boxbgcolor">
	<param value="white" name="boxfgcolor">
	<param value="Downloading JmolApplet ..." name="boxmessage">
	<param value="JmolApplet0.jar" name="archive">
	<param value="true" name="mayscript">
	<param value="'.Yii::app()->baseUrl.'/'.Yii::app()->params->appletDir.'jmol" name="codebase">
	<param value="JmolApplet" name="code">
	<param value="-Xmx512m" name="java_arguments">
	<param value="'.$struct.'" name="loadInline">
	<param value="select *" name="script">
</object>
<script type="text/javascript" src = "'.Yii::app()->baseUrl.'/'.Yii::app()->params->appletDir.'jmol/Jmol.js"></script>
<applet id = "'.Yii::app()->params->structAppletName.'" codebase = "'.Yii::app()->request->baseUrl.'/'.Yii::app()->params->appletDir.'" code="'.Yii::app()->params->structAppletName.'.class" archive="'.Yii::app()->params->structAppletName.'.jar" width="0" height="0">
	<param name="options" value="depict">
	<param name="mol" value="'.$struct.'">
</applet>';
					}
					?> 
	<div style = "position:relative;width:100%;height:600px;background:white;">
		<div style = "position:absolute;width:600px;height:600px;background:white;top:0px;left:0px">
			<?php
			echo CHtml::tag('img',
				array(
					'src' => Yii::app()->request->baseUrl.'/'.Yii::app()->params->tempDir.$sscreenCurveBrowserName,
					'alt' => $title,
				));
			?> 
		</div>
		<div style = "position:absolute;width:300px;height:600px;background:white;top:0px;left:610px">
			<h3>Parameters</h3>
			<? echo $molStructData; ?><br>
			<b>Identifier:</b> <?php echo CHtml::link($sscreenCurveModel->mol->name,Yii::app()->createUrl('molData/view', array('id'=> $sscreenCurveModel->mol_id)), array('target' => '_blank')); ?><br>

			<?php 
				$form=$this->beginWidget('CActiveForm', array(
					'id'	=>'mol_view_form',
					'action'=>Yii::app()->createUrl('pscreen/localstructsearch'),
					'method'=>'post',
					'htmlOptions'=>array('target'=>'_blank'),
				)); 
			?>
			
			<b>Attachments</b> (<?php echo CHtml::link(''.count($sscreenModel->sscreenAttachments),Yii::app()->createUrl('sscreenAttachment/index', array('Sscreen[id]'=> $sscreenModel->id)), array('target' => '_blank'));?>)<br>
			<?php echo CHtml::submitButton('Local Struct. Search',array('onclick' => 'javascript: getElementById("search_input_jme").value = document.'.Yii::app()->params->structAppletName.'.jmeFile();')); ?>
			<?php echo CHtml::submitButton('PubChem Struct. Search',array('onclick' => 'javascript:  getElementById("mol_view_form").action = "'.Yii::app()->createUrl('pscreen/pubchemstructsearch').'"; getElementById("search_input_jme").value = document.'.Yii::app()->params->structAppletName.'.jmeFile();')); ?>
			<?php echo CHtml::submitButton('ChemSpider Struct. Search',array('onclick' => 'javascript:  getElementById("mol_view_form").action = "'.Yii::app()->createUrl('pscreen/chemspiderstructsearch').'"; getElementById("search_input_jme").value = document.'.Yii::app()->params->structAppletName.'.jmeFile();')); ?>
			<?php echo CHtml::submitButton('ZINC Struct. Search',array('onclick' => 'javascript:  getElementById("mol_view_form").action = "'.Yii::app()->createUrl('pscreen/zincstructsearch').'"; getElementById("search_input_jme").value = document.'.Yii::app()->params->structAppletName.'.jmeFile();')); ?>
			<br><br>
			<?php 
				echo CHtml::hiddenField('search[input][jme]', '');
				$this->endWidget(); 
			?>
			<h5>Constants:</h5>
			<?php
			$sscreenCurveValues = '';
			$sscreenResultValues = "Conc.\tActivity\tUsed\n";
			if(isset($sscreenCurveData['func']) && isset(Yii::app()->params->drcFunctions[$sscreenCurveData['func']]))
			{
					$sscreenCurveData['func'] = Yii::app()->params->drcFunctions[$sscreenCurveData['func']];
			}
			foreach($sscreenCurveData as $k => $v)
			{
				if(strcmp($k, 'xs') != 0 && strcmp($k, 'ys') != 0 && strcmp($k, 'uses') != 0)
				{
					if(is_numeric($v))
					{
						$v = round($v,4);
					}                
					$sscreenCurveValues .= ucfirst($k).":\t".$v."\n";
				}
			}
			$i = 0;
			foreach($sscreenCurveData['xs'] as $x)
			{
				$sscreenResultValues .= $x."\t".$sscreenCurveData['ys'][$i]."\t".$sscreenCurveData['uses'][$i]."\n";
				$i++;
			}
			echo CHtml::textArea('sscreen_curve_values',$sscreenCurveValues, array('style' => 'width:240px;height:150px'));
			?> 
			<h5>Points:</h5>
			<?php
			echo CHtml::textArea('sscreen_result_values',$sscreenResultValues, array('style' => 'width:240px;height:150px'));
			?> 
		</div>
	</div>
	<div id = 'Sscreen_info' style = 'position:absolute;left:0px;top:605px;width:600px;height:100px;'>
		<table  style = 'font-size:0.8em;'>
			<tr>
			<?php
			$count = 0;
			if(isset($stats))
			{
				foreach($stats as $k=>$v)
				{
					echo '<td><b>'.$k.':</b></td><td>'.$v."</td>";
					$count++;
					if($count%2 == 0)
					{
						echo "</tr>\n<tr>";
					}
				}
			}
			?>
			</tr>
		</table>
	</div>
					<?php
					return;
				}
			}
            echo 'MISSING DATA';
            return;
        }
        echo 'No Secondary Screen Loaded';
		}catch(Exception $e)
		{
			print_r($e);
		}
    }
    
    public function actionEditorChangeCurve()
    {
        if(isset($_POST['settings']['sscreen_id']) && isset($_POST['settings']['mol_id']))
        {
            $sscreenModel = Sscreen::model()->findByPk($_POST['settings']['sscreen_id']);
            $molDataModel = MolData::model()->findByPk($_POST['settings']['mol_id']);
            
			try
			{
				if(isset($sscreenModel) && isset($molDataModel))
				{
					$file = $sscreenModel->dataUploadDir.$molDataModel->name.'.'.Yii::app()->params->dataFileFormat;
					$sscreenCurveData = $sscreenModel->getFirstCurveDataFromFile($molDataModel->id,$file);
					$this->renderPartial('_presentEditor',array(
						'model'     =>$sscreenModel,
						'curve'		=>array('mol_id' => $molDataModel->id, 'func' => $sscreenCurveData['func']),
						'curveData' =>$sscreenModel->getCurveDataFromFile($molDataModel->id,$file),
						'stats' 	=>$sscreenModel->getCurveClassification($sscreenModel->getSpecificCurveDataFromFile($sscreenCurveData['func'],$molDataModel->id,$file)),
					));            
					return;
				}
			}
			catch(Exception $e)
			{
				print_r($e);
			}
        }
        echo 'Secondary Screen Editor Settings Missing';
    }
    
    public function actionEditorChangeFunction()
    {
        if(isset($_POST['settings']['sscreen_id']) && isset($_POST['settings']['mol_id']) && isset($_POST['settings']['function']))
        {
            $sscreenModel = Sscreen::model()->findByPk($_POST['settings']['sscreen_id']);            
            $molDataModel = MolData::model()->findByPk($_POST['settings']['mol_id']);
                       
            if(isset($sscreenModel) && isset($molDataModel))
            {
				$file = $sscreenModel->dataUploadDir.$molDataModel->name.'.'.Yii::app()->params->dataFileFormat;
				$sscreenCurveData = $sscreenModel->getCurveDataFromFile($molDataModel->id,$file);
                $this->renderPartial('_presentEditor',array(
                    'model'     =>$sscreenModel,
                    'curve'		=>array('mol_id' => $molDataModel->id, 'func' => $_POST['settings']['function']),
                    'curveData' =>$sscreenCurveData,
					'stats' 	=>$sscreenModel->getCurveClassification($sscreenModel->getSpecificCurveDataFromFile($_POST['settings']['function'],$molDataModel->id,$file)),
                ));            
                return;
            }
        }
        echo 'Secondary Screen Editor Settings Missing';
    }
	
	public function actionEditorRefitCurve()
    {
        if(isset($_POST['settings']['sscreen_id']) && isset($_POST['settings']['mol_id']) && isset($_POST['settings']['function']) && isset($_POST['settings']['uses']))
        {
            $sscreenModel = Sscreen::model()->findByPk($_POST['settings']['sscreen_id']);            
            $molDataModel = MolData::model()->findByPk($_POST['settings']['mol_id']);
                       
            if(isset($sscreenModel) && isset($molDataModel))
            {			
				$file 				= $sscreenModel->dataUploadDir.$molDataModel->name.'_tmp.'.Yii::app()->params->dataFileFormat;
				$sscreenCurveData 	= $sscreenModel->getCurveDataFromFile($molDataModel->id,$file);
				$uses 				= $this->parseUses($_POST['settings']['uses'], count($sscreenCurveData['xs']));
				$sscreenCurveData['uses'] = $uses;
				
                $this->renderPartial('_presentEditor',array(
                    'model'     =>$sscreenModel,
                    'curve'		=>array('mol_id' => $molDataModel->id, 'func' => $_POST['settings']['function']),
                    'curveData' =>$sscreenCurveData,
                ));
				if(is_file($file))
				{
					unlink($file);
				}
                return;
            }
        }
        echo 'Secondary Screen Editor Settings Missing';
    }
	
	public function actionMakeSscreenCurveFromFile()
    {
 		if(isset($_POST['Sscreen']) && isset($_POST['MolData']))
		{
            $molDataModel	= MolData::model()->findByPk($_POST['MolData']['id']);
            $sscreenModel   = Sscreen::model()->findByPk($_POST['Sscreen']['id']);
            if(isset($molDataModel) && isset($sscreenModel))
            {
				$file = $sscreenModel->dataUploadDir.$molDataModel->name.'.'.Yii::app()->params->dataFileFormat;
                $sscreenCurveData   = $sscreenModel->getFirstCurveDataFromFile($molDataModel->id, $file);
            
                if(isset($sscreenCurveData) && $sscreenCurveData)
                {
                    $sscreenCurveBrowserName 	= 'sscreen_curve_browser_'.md5(gettimeofday(TRUE)).'.png';
                    $title 						= 'Secondary Screen '.$molDataModel->name.' for '.$sscreenModel->name;
                    $sscreenCurveBrowser		= new SscreenGrapher($title, $_POST['Sscreen']['id'], 500, 500);
                    $sscreenCurveBrowser->graphDoseResponseCurve($sscreenCurveData, Yii::app()->params->tempDir.$sscreenCurveBrowserName);

                    echo CHtml::tag('img',
                        array(
                            'src' => Yii::app()->request->baseUrl.'/'.Yii::app()->params->tempDir.$sscreenCurveBrowserName,
                            'alt' => $title,
                        ));
                    return;
                }
            }
            echo 'DATA COULD NOT BE FIT';
            return;
        }
        echo 'No Secondary Screen Loaded';
    }
	
	public function actionMakeSpecificSscreenCurveFromFile()
    {
 		if(isset($_POST['settings']['sscreen_id']) && isset($_POST['settings']['mol_id']))
		{
			$sscreenModel   = Sscreen::model()->findByPk($_POST['settings']['sscreen_id']);
            $molDataModel	= MolData::model()->findByPk($_POST['settings']['mol_id']);
            if(isset($molDataModel) && isset($sscreenModel))
            {
				$file = $sscreenModel->dataUploadDir.$molDataModel->name.'.'.Yii::app()->params->dataFileFormat;
                $sscreenCurveData   = $sscreenModel->getSpecificCurveDataFromFile($_POST['settings']['function'], $molDataModel->id, $file);
                if(isset($sscreenCurveData))
                {
                    $sscreenCurveBrowserName 	= 'sscreen_curve_browser_'.md5(gettimeofday(TRUE)).'.png';
                    $title 						= 'Secondary Screen '.$molDataModel->name.' for '.$sscreenModel->name;
                    $sscreenCurveBrowser		= new SscreenGrapher($title, $_POST['settings']['sscreen_id'], 500, 500);
                    $sscreenCurveBrowser->graphDoseResponseCurve($sscreenCurveData, Yii::app()->params->tempDir.$sscreenCurveBrowserName);

                    echo CHtml::tag('img',
                        array(
                            'src' => Yii::app()->request->baseUrl.'/'.Yii::app()->params->tempDir.$sscreenCurveBrowserName,
                            'alt' => $title,
                        ));
                    return;
                }
            }
            echo 'MISSING DATA';
            return;
        }
        echo 'No Secondary Screen Loaded';
    }
    
    public function actionMakeSscreenCurveFromEditor()
    {
		if(isset($_POST['settings']['sscreen_id']) && isset($_POST['settings']['mol_id']))
		{
			$sscreenModel   = Sscreen::model()->findByPk($_POST['settings']['sscreen_id']);
            $molDataModel	= MolData::model()->findByPk($_POST['settings']['mol_id']);
            if(isset($molDataModel) && isset($sscreenModel))
            {
				$sscreenCurveData 			= $_POST['settings']['constantArray'];
				$sscreenCurveData['func'] 	= $_POST['settings']['function'];
				$sscreenCurveData 			= array_merge($sscreenCurveData, $sscreenModel->getCurvePoints($molDataModel->id));
            
                if(isset($sscreenCurveData))
                {
					$uses = $this->parseUses($_POST['settings']['uses'], count($sscreenCurveData['xs']));
					
                    $sscreenCurveBrowserName 	= 'sscreen_curve_browser_'.md5(gettimeofday(TRUE)).'.png';
                    $title 						= 'Secondary Screen '.$molDataModel->name.' for '.$sscreenModel->name;
                    $sscreenCurveBrowser		= new SscreenGrapher($title, $_POST['settings']['sscreen_id'], 500, 500);
                    $sscreenCurveBrowser->graphDoseResponseCurve($sscreenCurveData, Yii::app()->params->tempDir.$sscreenCurveBrowserName, $uses);

                    echo CHtml::tag('img',
                        array(
                            'src' => Yii::app()->request->baseUrl.'/'.Yii::app()->params->tempDir.$sscreenCurveBrowserName,
                            'alt' => $title,
                        ));
                    return;
                }
            }
            echo 'MISSING DATA';
            return;
        }
        echo 'No Secondary Screen Loaded';
    }
	
	public function actionEditorSaveCurve()
    {
		if(isset($_POST['settings']['sscreen_id']) && isset($_POST['settings']['mol_id']))
		{
			$sscreenModel   = Sscreen::model()->findByPk($_POST['settings']['sscreen_id']);
            $molDataModel	= MolData::model()->findByPk($_POST['settings']['mol_id']);
            if(isset($molDataModel) && isset($sscreenModel))
            {
				$file = $sscreenModel->dataUploadDir.$molDataModel->name.'.'.Yii::app()->params->dataFileFormat;
				$sscreenCurveData 	= $sscreenModel->getCurveDataFromFile($molDataModel->id,$file);
				
                if(isset($sscreenCurveData))
                {
					$xs = $sscreenCurveData['xs'];
					$uses = $this->parseUses($_POST['settings']['uses'], count($xs));
					
					unset($sscreenCurveData['xs']);
					unset($sscreenCurveData['ys']);
					unset($sscreenCurveData['uses']);
					
					if(strcmp($_POST['settings']['function'],'NoFit') == 0)
					{
						$_POST['settings']['constantArray'] = array();
					}
					$sscreenCurvePoints	= $sscreenModel->getCurvePoints($molDataModel->id);
					$i = -1;
					foreach($sscreenCurveData as $key => $curve)
					{
						if(strcmp($curve['func'], $_POST['settings']['function']) == 0)
						{
							$sscreenCurveData[$key] 		= $_POST['settings']['constantArray'];
							$sscreenCurveData[$key]['func']	= $_POST['settings']['function'];
							$sscreenCurveData[$key]['r2'] 	= $sscreenModel->getCurveR2($_POST['settings'], $sscreenCurvePoints, $uses);
							$i = $key;
						}
					}

					if($i > 0)
					{
						$temp = $sscreenCurveData[$i];
						unset($sscreenCurveData[$i]);
						array_unshift($sscreenCurveData,$temp);
					}
					else if($i == -1)
					{
						array_unshift($sscreenCurveData, array());
						$sscreenCurveData[0] 			= $_POST['settings']['constantArray'];
						$sscreenCurveData[0]['func'] 	= $_POST['settings']['function'];
						$sscreenCurveData[0]['r2'] 		= $sscreenModel->getCurveR2($_POST['settings']['function'], $sscreenCurvePoints, $uses);
					}

					echo 'SAVING...<br>';
					
					if($sscreenModel->saveCurvesToFile($sscreenCurveData, $file))
					{
						echo 'SAVED TO DISK...<br>';
					}
					else
					{
						echo 'COULD NOT SAVE TO DISK...<br>';
					}

					foreach($xs as $i => $x)
					{
						$sscreenResultModel = SscreenResult::model()->findByAttributes( 
							array(
								'mol_id' 		=> $_POST['settings']['mol_id'], 
								'sscreen_id' 	=> $_POST['settings']['sscreen_id'], 
								'concentration' => $x,
							));
						if(isset($sscreenResultModel))
						{
							$sscreenResultModel->status = $uses[$i];
							$sscreenResultModel->save();
						}
					}
					echo 'SAVED POINT STATUSES...<br>';
					echo 'SAVE SUCCESSFUL...<br>';                    
                    return;
                }
            }
            echo 'MISSING DATA';
            return;
        }
        echo 'No Secondary Screen Loaded';
    }
	
	public function actionMakeRefitSscreenCurveFromEditor()
    {
		if(isset($_POST['settings']['sscreen_id']) && isset($_POST['settings']['mol_id']))
		{
			$sscreenModel   = Sscreen::model()->findByPk($_POST['settings']['sscreen_id']);
            $molDataModel	= MolData::model()->findByPk($_POST['settings']['mol_id']);
            if(isset($molDataModel) && isset($sscreenModel))
            {
				$sscreenCurvePoints	= $sscreenModel->getCurvePoints($molDataModel->id);
                if(isset($sscreenCurvePoints))
                {
					$uses = $this->parseUses($_POST['settings']['uses'], count($sscreenCurvePoints['xs']));
					
					$file = $sscreenModel->dataUploadDir.$molDataModel->name.'_tmp.'.Yii::app()->params->dataFileFormat;
					if(is_file($file))
					{
						unlink($file);
					}
					$sscreenModel->refitCurveData($sscreenCurvePoints, $uses, $_POST['settings']['fix'], $file);
					$sscreenCurveData   		= $sscreenModel->getSpecificCurveDataFromFile($_POST['settings']['function'], $molDataModel->id, $file);
					$sscreenCurveBrowserName 	= 'sscreen_curve_browser_'.md5(gettimeofday(TRUE)).'.png';
                    $title 						= 'Secondary Screen '.$molDataModel->name.' for '.$sscreenModel->name;
                    $sscreenCurveBrowser		= new SscreenGrapher($title, $_POST['settings']['sscreen_id'], 500, 500);
                    $sscreenCurveBrowser->graphDoseResponseCurve($sscreenCurveData, Yii::app()->params->tempDir.$sscreenCurveBrowserName, $uses);

                    echo CHtml::tag('img',
                        array(
                            'src' => Yii::app()->request->baseUrl.'/'.Yii::app()->params->tempDir.$sscreenCurveBrowserName,
                            'alt' => $title,
                        ));
                    return;
                }
            }
            echo 'MISSING DATA';
            return;
        }
        echo 'No Secondary Screen Loaded';
    }
	
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 */
	public function loadModel()
	{
		if($this->_model===null)
		{
			if(isset($_GET['id']))
				$this->_model=Sscreen::model()->findbyPk($_GET['id']);
			if($this->_model===null)
				throw new CHttpException(404,'The requested page does not exist.');
		}
		return $this->_model;
	}
	
	public function parseUses($enables, $num)
	{
		$uses = array();
		for($i = 0; $i < $num; $i++)
		{
			$uses[$i] = 0;
		}
		
		foreach($enables as $enable)
		{
			$uses[$enable] = 1;
		}
		return $uses;
	}

	/**
	 * Performs the AJAX validation.
	 * @param CModel the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='sscreen-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
