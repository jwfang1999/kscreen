<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# CSVPlate.php is part of K-Screen Version 1.1.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#
class CSVPlate
{
    private $csvFile;
    private $regEx;
    private $fullRegEx;
    private $rows;
	private $numRows;
	private $numCols;
	private $seps;
	private $data;
	private $numPlates;
    
    public function CSVPlate($f, $rx, $rs, $cs, $s = ',')
    {
        $this->csvFile = $f;
		$this->regEx = $rx;
		$this->rows = $rs;
		$this->numRows = count($rs);
		$this->numCols = $cs;
		$this->sep = $s;
		$this->fullRegEx = $rx;
		$this->numPlates = 0;
		for($c = 1; $c < $this->numCols; $c++)
		{
			$this->fullRegEx .= $this->sep.$this->regEx;
		}
		
		$this->data = array();
    }
	
	public function load()
	{
		$fh = fopen($this->csvFile,'r');
		
		while($line = fgets($fh))
		{
			$line = preg_replace('/["\'\s+]/','', $line);
			if(preg_match('/'.$this->fullRegEx.'/', $line, $matches))
			{
				$this->data[] = $matches[0];
				if(count($this->data) % $this->numRows == 0 || count($this->data) == 1)
				{
					$this->numPlates++;
				}
			}
		}
		
		fclose($fh);
	}
	
	public function getNumPlates()
	{
		return $this->numPlates;
	}
	
	public function writeString($startPlate)
	{
		$str = '';
		for($r = 0; $r < count($this->data); $r++)
		{
			$str .= ($startPlate+floor($r/$this->numRows)).$this->sep.$this->rows[$r%$this->numRows].$this->sep.$this->data[$r]."\n";
		}
		return $str;
	}
}

?>