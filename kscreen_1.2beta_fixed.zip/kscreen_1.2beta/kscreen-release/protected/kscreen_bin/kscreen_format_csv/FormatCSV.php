<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# FormatCSV.php is part of K-Screen Version 1.1.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#
require_once('CSVHelper.php');
require_once('CSVPlate.php');


$validInput = false;
$csvFiles = array();
$csvNum = 0;
$fh;

$length = count($argv);
if($length > 2)
{
    for($i = 1; $i < $length - 1; $i++)
    {
        foreach(glob($argv[$i]) as $file)
        {
            $csvFile = $file;
            echo "Processing File: ".$csvFile."\n";
            $csvFiles[] = $csvFile;
            $validInput = true;
        }
        
        if(!$validInput)
        {
            echo 'Cannot find '.$argv[$i].".\n";
        }
        $validInput = false;
    }
    
    $csvNum = count($csvFiles);
    $validInput = $csvNum != 0;
    
    try
    {
        $file = $argv[$length-1];
        $fh = fopen($file,'w');
    }
    catch(Exception $e)
    {
        $fclose($fh);
        echo 'Error: Cannot open output file '.$file.".\n";
    }
}

if(!$validInput)
{
    if($csvNum == 0)
    {
        echo 'Error: No files to format.'."\n";
    }
    else
    {
        echo 'Error, Usage: php '.$argv[0].' [CSV Files/Patterns] [Output CSV]'."\n";
    }
	exit();
}

$parseParams = PARSE_PARAMS();
$header = $parseParams['header'];
for($i = 1; $i <= $parseParams['cols']; $i++)
{
	$header .= ','.$i;
}
$header.="\n";

$plateNum = 1;
$plateMap = array();
$str = $header;

foreach($csvFiles as $csvFile)
{
    $csvPlate = new CSVPlate($csvFile, $parseParams['dataRegEx'], $parseParams['rows'], $parseParams['cols']);
	$csvPlate->load();
	$str .= $csvPlate->writeString($plateNum);
	$newPlateNum = $plateNum + $csvPlate->getNumPlates()-1;
	for($i = $plateNum; $i < $newPlateNum; $i++)
	{
		$plateMap[$i] = array($i - $plateNum + 1, $csvFile);
	}
	$plateNum = $newPlateNum;
}

for($i = 1; $i < $plateNum; $i++)
{
	echo 'Output Plate '.$i.' read from '.$plateMap[$i][1].", Plate ".$plateMap[$i][0]."\n";
}

fwrite($fh, $str);
fclose($fh);
?>