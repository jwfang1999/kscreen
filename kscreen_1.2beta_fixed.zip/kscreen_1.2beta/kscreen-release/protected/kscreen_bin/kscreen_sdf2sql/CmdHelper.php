<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# CmdHelper.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#

class CmdHelper
{
	private $isWin;
	private $tempDir;
	public function __construct($td = '.')
	{
		$this->isWin 	= preg_match('/WIN/i',PHP_OS);
		$this->tempDir 	= $td;
	}
	
	//Start Algorithm Snippet From MolDB5
	function filterThroughCmd($input, $cmdLine) 
	{
		$output = '';
		if($this->isWin)
		{
			$tempdir = realpath($this->tempDir);
			$tmpfname = tempnam($tempdir, "mdb"); 
			$tfhandle = fopen($tmpfname, "wb");
			$myInput = str_replace("\n","",$input);
			$myInput = str_replace("\\\$","\$",$myInput);
			$inputlines = explode("\r",$myInput);
			$newInput = implode("\r\n",$inputlines);
			fwrite($tfhandle, $newInput);
			fclose($tfhandle);
			$output = shell_exec("type \"$tmpfname\" | $cmdLine ");
			//echo "type '$tmpfname' | $cmdLine <br>";
			unlink($tmpfname);
		}
		else
		{
			$pipe = popen("echo \"$input\"|$cmdLine" , 'r');
			if (!$pipe) 
			{
				return false;
			}
			$output = '';
			while(!feof($pipe)) 
			{
				$output .= fread($pipe, 1024);
			}
			pclose($pipe);
		}
		return $output;
	}
	
	function filterThroughCmdSTERR($input, $cmdLine) 
	{
		$output = '';
		if($this->isWin)
		{
			$tempdir = realpath($this->tempDir);
			$tmpfname = tempnam($tempdir, "cmpdimport"); 
			$tfhandle = fopen($tmpfname, "wb");
            $myInput = str_replace("\$","\$",$input);
			$myInput = str_replace("\r","",$myInput);
            $myInput = str_replace("\n","\r\n",$myInput);
			fwrite($tfhandle, $myInput);
			fclose($tfhandle);
			$output = shell_exec("$cmdLine < \"$tmpfname\" 2>&1");
			//echo "type '$tmpfname' | $cmdLine <br>";
			unlink($tmpfname);
		}
		else
		{
			$pipe = popen("echo \"$input\"|$cmdLine 2>&1 | more" , 'r');
			if (!$pipe) 
			{
				return false;
			}
			$output = '';
			while(!feof($pipe)) 
			{
				$output .= fread($pipe, 1024);
			}
			pclose($pipe);
		}
		return $output;
	}
	//End Algorithm Snippet From MolDB5
}
?>