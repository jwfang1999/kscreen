<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# SDF.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#

class SDF
{
	public $name;
	public $structure;
	private $tags;
	
	public function __construct($n = '', $struct = '')
	{
		$this->name = $n;
		$this->structure = $n."\n".$struct;
		$this->tags = array();
	}

	public function editTag($t, $v)
	{
		if(is_array($t))
		{
			$vArray = is_array($v);
			foreach($t as $k=>$i)
			{
				if($vArray)
				{
					$this->tags[$i] = $v[$k];
				}
				else
				{
					$this->tags[$i] = $v;
				}
			}
		}
		else
		{
			$this->tags[$t] = $v;
		}
	}
	
	public function getTag($t)
	{
		if(isset($this->tags[$t]))
		{
			return trim($this->tags[$t]);
		}
		return false;
	}
	
	public function deleteTag($t)
	{
		if(is_array($t))
		{
			foreach($t as $i)
			{
				unset($this->tags[$i]);
			}
		}
		else
		{
			unset($this->tags[$t]);
		}
	}
	
	public function getTags()
	{
		return array_keys($this->tags);
	}
	
	public function toString()
	{
		$str = $this->structure."\n";
		foreach($this->tags as $k=>$v)
		{
			$str .= '>  <'.$k.">\n";
			$str .= $v."\n";
		}
		$str .= "$$$$\n";
		return $str;
	}
}