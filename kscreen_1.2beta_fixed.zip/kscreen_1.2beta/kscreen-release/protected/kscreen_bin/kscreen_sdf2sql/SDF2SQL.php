<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# SDF2SQL.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#
require_once('SDF2SQLHelpers.php');
require_once('SQLBuilder.php');
require_once('SDFParser.php');
require_once('CmdHelper.php');
require_once('SDF2SQLConfig.php');

$sdfFile = '*.sdf';
$sqlFile = 'result'; // No longer Used
$writeSQLFile = false; // No longer Used
$fileName = '';
$validInput = false;

if(count($argv) > 1)
{
	if(is_file($argv[1]))
	{
		$sdfFile = $argv[1];
		echo "Processing File: ".$sdfFile."\n";
		$validInput = true;
		$fileName = preg_split('/\./', $argv[1]);
		$fileName = $fileName[0];
		/*if(isset($argv[2]))
		{
			$sqlFile = preg_split('/\./', $argv[2]);
			$sqlFile = $sqlFile[0];
            $writeSQLFile = true;
		}*/
	}
	else
	{
		echo $argv[1]." is not a valid file.\n";
	}
}

if(!$validInput)
{
	echo 'Error, Usage: php '.$argv[0].' [SDF File] '."\n";//[Optional: Output SQL File]'."\n";
	exit();
}

$sdfParser = new SDFParser($sdfFile);
$execs = EXECS();
$tableMapping = TABLES_MAP();
$imageOpts = IMAGE_OPTS();

# check for execs
foreach($execs as $exec)
{
	$retVal = shell_exec($exec.' -v');
	if(!preg_match("/Usage:/", $retVal) && !preg_match("/Ghostscript/",$retVal))
	{
		echo "ERROR: could not find '$exec', make sure it is installed";	
		exit();
	}  
}

if(!is_dir($imageOpts['img_dir']))
{
    if(!mkdir($imageOpts['img_dir']))
    {
        echo "ERROR: could not create directory ".$imageOpts['img_dir'].", make sure it accessible.";
        exit();
    }
}

$dbParams = DATABASE_PARAMS();

$DB = mysql_connect($dbParams['server'], $dbParams['username'], $dbParams['password']) or die("Could not connect to database server!");
if(!$DB)
{
	echo "ERROR: database could not be accessed";	
	exit();
}

if(!mysql_select_db($dbParams['db'],$DB))
{
	echo "ERROR: could not select database!\n";
	$results = mysql_query('SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = "'.$dbParams['db'].'"', $DB);
	$hasDB = mysql_fetch_assoc($results);
	if(count($hasDB) > 0)
	{
		$makeDB = false;
		do
		{
			echo "Database does not exist, create new database? (Y/N)";
			$c = substr(fgets(STDIN),0,1);
			if(strcmp($c,'Y') == 0 || strcmp($c,'y') == 0)
			{
				echo 'Creating new DB '.$dbParams['db']."...\n";
				$makeDB = true;
			}
			else if(strcmp($c,'N') == 0 || strcmp($c,'n') == 0)
			{
				echo "Stopping...\n";
				exit();
			}
		}
		while(!$makeDB);
		
		$schemaFile = SCHEMA_FILE();
		$sql = 'START TRANSACTION;
CREATE DATABASE `'.$dbParams['db'].'`;
USE `'.$dbParams['db'].'`;
';
		$sql .= file_get_contents($schemaFile['file']);
		$sqls = preg_split('/;(\n|\r)+/', $sql);
		foreach($sqls as $sqlCmd)
		{
			mysql_query(trim($sqlCmd).';', $DB);
		}
		echo "DB created!\n";
		mysql_select_db($dbParams['db'],$DB);
	}
}

$results = mysql_query('SHOW TABLE STATUS LIKE "'.$tableMapping['data'].'"', $DB);
$row = mysql_fetch_assoc($results);
$id = $row['Auto_increment'];

$results = mysql_query('SELECT MAX(upload_id) FROM "'.$tableMapping['data'].'"', $DB);
$row = mysql_fetch_assoc($results);
$uploadId = $row['upload_id']+1;

$dicts = getDicts($DB);
$sqlBuilder = new SQLBuilder($sqlFile);

$result = $sdfParser->parseNext();

$invalidMols = array();
$num = 0;

while($result !== false)
{
	$makeImages = true;
	$num++;
	if(isValidMol($result->structure))
	{
		echo "Starting Entry #$num\n";
		$store = array('structure' => $result->structure);
		$inserts = array();
		$inserts[$tableMapping['data']]     = formatForMolDataTable($result, '%id', $DB);
		$inserts[$tableMapping['data']]['upload_id'] = $uploadId;
		$inserts[$tableMapping['struct']]   = formatForMolStructTable($result, '%id');
		if(formatForMolStatFGBCFP($inserts, $result, $dicts, '%id') === false)
		{
			echo " ERROR: Invalid Structure, skipping fingerprinting step.";
			$makeImages = false;
		}
		
		$sqlLines = $sqlBuilder->getInsertStatements($inserts, true);
		if($sqlLines !== false)
		{
			$goodID = false;
			$duplicate = false;
			while(!$goodID && !$duplicate)
			{
				echo " Trying ID: $id\n";
				$line = preg_replace('/%id/', $id, $sqlLines[0]);
				if(mysql_query($line) !== false)
				{
					$goodID = true;
					unset($sqlLines[0]);
				}
				else
				{
					$str = mysql_error();
					
					if(preg_match('/Duplicate entry/', $str) && !preg_match('/\'id\'/', $str))
					{
						$duplicate = true;
					}
					else
					{
						echo $str."\n";
						echo " ID $id Taken\n";
						$id++;
					}
				}
			}
			if($duplicate)
			{
				echo " MySQL Error: Duplicate Entry\n";
			}
			else
			{
				$picInsert = array();
				if($makeImages)
				{
					$picInsert[$tableMapping['img']] = createBitmap($result->structure, $id, $imageOpts['img_dir'], $imageOpts['mol2psopt'], $imageOpts['scale_factor']);
				}
				$picSqlLines = $sqlBuilder->getInsertStatements($picInsert, true);
				$sqlLines = $sqlBuilder->wrapTransaction(array_merge($sqlLines, $picSqlLines));
				$success = true;
				foreach($sqlLines as $sqlLine)
				{
					$sqlCmd = preg_replace('/"?%id"?/', $id, $sqlLine);
					if($success && !mysql_query($sqlCmd))
					{
						echo $sqlCmd."\n";
						$success = false;
					}
				}
				if($success)
				{
					echo ' Insert Successful!'."\n";
				}
				else
				{
					echo ' MySQL Error: '.mysql_error()."\n";
					echo ' Insert Failed!'."\n";
					$deleteSql = 'DELETE FROM '.$tableMapping['data'].' WHERE `id` = '.$id;
					mysql_query($deleteSql);
				}
				$id++;
			}
		}
		else
		{
			echo "SQL Error";
		}
		echo "Entry #$num Done\n";
	}
	else
	{
		echo "Invalid Molecule Detected\n";
		$invalidMols[] = $result;
	}
	$result = $sdfParser->parseNext();
}

if(count($invalidMols) > 0)
{
	$fh = fopen($fileName.'_'.count($invalidMols).'_failed_mols.txt','w');
	foreach($invalidMols as $invalidMol)
	{
		fwrite($fh, $invalidMol->toString());
	}
	fclose($fh);
}

mysql_close($DB);

/**/
?>