<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# SDF2SQLConfig.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#

function DATABASE_PARAMS()
{
	return array(
		'server' => 'localhost',
		'username' => 'USER',
		'password' => 'PASSWORD',
		'db' => 'KSCREEN_DATABASE_NAME',
		);
}

function IMAGE_OPTS()
{
	return array(
		'img_dir' 		=> '../../../file_store/bitmaps',
		'mol2psopt' 	=> '--rotate=auto3Donly --hydrogenonmethyl=off', 
		'scale_factor' 	=> 0.22
		);
}

function SCHEMA_FILE()
{
	return array(
		'file' => 'kscreenCleanSchema.sql',
		'hasSchema' => true,
		'hasTables' => true,
		);
}

function EXECS()
{
    $ret = array();
	if(preg_match('/WIN/i',PHP_OS))
	{
		$ret['CHECKMOL'] = 'checkmol';
		$ret['MATCHMOL'] = 'matchmol';
		$ret['MOL2PS']	= 'mol2ps';
		$ret['GS']	= 'gswin32c';
	}
	else
	{
		$ret['CHECKMOL'] = '../check_match_mol_nix/checkmol';
		$ret['MATCHMOL'] = '../check_match_mol_nix/matchmol';
		$ret['MOL2PS']	= '../mol2ps_nix/mol2ps-0.2a-linux-i386';
		$ret['GS']	= 'ghostscript';
	}
    return $ret;
}

function TWEAK_MOL()
{
    return true;
}

function TABLES_MAP()
{
    $map = array(
        'data' => 'mol_data',
        'struct' => 'mol_struct',
        'cfp' => 'mol_cfp',
        'fgb' => 'mol_fgb',
        'img' => 'mol_img',
        'picstat' => 'mol_picstat',
        'stats' => 'mol_stat',
        'fpdef' => 'mol_fpdef',
        );
    return $map;
}

function SDF2DB_ATRRIBUTE_MAP()
{
	//Set the SDF => database field mappings here:
	//	[SDF Field] => [Database Field]
	//	or
	//	[SDF Field] => [Array of Database Fields]
	//	or
	//	[SDF Field] => [Look up instructions, 
	//						'.table' => (look up table name), 
	//						'.query' => (Array of Parameters, 
	//							'.attr' => <field to query>,
	//							'.get' => <field to return>,
	//							'.set' => <field in table to set>
	//					)]
	//	or
	//	['.*']		=> [Field where extraneous fields go to,
	//						'.colName' => <field in table to set>]
	//						'.length' => <limit of field size>]
	//					)]
	$map = array( 
		'supplier_tag' 	=> 'supplier_tag',
		'mplate' 		=> 'mplate',
		'mrow'	 		=> 'mrow',
		'mcol'	 		=> 'mcol',
		'supplier_id'	=> 'supplier_id',
		/*'supplier_name' => array(
							'.table' => 'supplier', 
							'.query' => array(
								'.attr' => 'company', 
								'.get' => 'id', 
								'.set' => 'supplier_id'
							)),*/
		'ku_id'			=> array('name', 'alias'),
		'description'	=> 'description',
		'formula'    	=> 'formula',
		'pubchem_id'    	=> 'pubchem_id',
		'lot'	    	=> 'lot',
		'purity'		=> 'purity',
		'.*'			=> array('.colName' => 'description', '.length' => 1024),
		);
		
	return $map; 
}

?>