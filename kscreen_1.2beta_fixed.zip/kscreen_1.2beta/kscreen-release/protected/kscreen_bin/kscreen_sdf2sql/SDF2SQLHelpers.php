<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# SDF2SQLHelpers.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#
function getDicts($DB)
{
    $tableMapping = TABLES_MAP();
    $result = mysql_query('SELECT fpdef, fptype FROM '.$tableMapping['fpdef'], $DB);
	//echo 'SELECT fpdef, fptype FROM '.$tableMapping['fpdef'];
	$fpStruct = array();
	$nDict = 0;
	while($ref = mysql_fetch_assoc($result))
	{
		$fpDef = $ref['fpdef'];
		if (strlen($fpDef) >20 ) 
		{
			$nDict++;
			$fpStruct[$nDict-1] = $fpDef;
			$dictNum = $nDict;
			while (strlen($dictNum) < 2)
			{ 
				$dictNum = "0" . $dictNum;
			}
			$fpType = $ref['fptype'];
		}
	}
	return $fpStruct;
}

function formatForMolDataTable(&$result, $id, $DB)
{
	$tags = $result->getTags();
	$mapping = SDF2DB_ATRRIBUTE_MAP();

	$insert = array();
	if($id !== false)
	{
		$insert['id'] = $id;
	}
	foreach($tags as $tag)
	{
		if(isset($mapping[$tag]))
		{
			if(is_array($mapping[$tag]))
			{
				if(isset($mapping[$tag]['.table']) && isset($mapping[$tag]['.query']) && isset($mapping[$tag]['.query']['.attr']) && isset($mapping[$tag]['.query']['.get']) && isset($mapping[$tag]['.query']['.set']))
				{
					$results = mysql_query('SELECT '.$mapping[$tag]['.query']['.get'].' FROM '.$mapping[$tag]['.table'].' WHERE '.$mapping[$tag]['.query']['.attr'].' = "'.$result->getTag($tag).'"', $DB);
					print_r(mysql_error($DB));
					$row = mysql_fetch_assoc($results);
					if(!$row)
					{
						if(mysql_query('INSERT into '.$mapping[$tag]['.table'].' ('.$mapping[$tag]['.query']['.attr'].') VALUES ("'.$result->getTag($tag).'");'))
						{
							echo 'Adding '.$result->getTag($tag).' to '.$mapping[$tag]['.table']."\n";
							$results = mysql_query('SELECT '.$mapping[$tag]['.query']['.get'].' FROM '.$mapping[$tag]['.table'].' WHERE '.$mapping[$tag]['.query']['.attr'].' = "'.$result->getTag($tag).'"', $DB);
							$row = mysql_fetch_assoc($results);
						}
					}
					if($row)
					{
						if(isset($insert[$mapping[$tag]['.query']['.set']]))
						{
							$insert[$mapping[$tag]['.query']['.set']] .= $row[$mapping[$tag]['.query']['.get']];
						}
						else
						{
							$insert[$mapping[$tag]['.query']['.set']] = $row[$mapping[$tag]['.query']['.get']];
						}
					}
				}
				else
				{
					foreach($mapping[$tag] as $field)
					{
						if(preg_replace('/[^A-Za-z0-9]/','',$field))
						{
							$insert[$field] = $result->getTag($tag);
						}
					}
				}
			}
			else
			{
				if(isset($insert[$mapping[$tag]]))
				{
					$insert[$mapping[$tag]] .= $result->getTag($tag);
				}
				else
				{
					$insert[$mapping[$tag]] = $result->getTag($tag);
				}
			}
		}
		else if(isset($mapping['.*']))
		{
			if(isset($insert[$mapping['.*']['.colName']]))
			{
				$insert[$mapping['.*']['.colName']] .= $tag."\n".$result->getTag($tag)."\n\n";
			}
			else
			{
				$insert[$mapping['.*']['.colName']] = $tag."\n".$result->getTag($tag)."\n\n";
			}
			$insert[$mapping['.*']['.colName']] = substr($insert[$mapping['.*']['.colName']],0,$mapping['.*']['.length']);
		}
	}
	return $insert;
}

function formatForMolStructTable(&$result, $id)
{
    $molecule = $result->structure;
    if(TWEAK_MOL())
    {
        $ch = new CmdHelper();
        $execs = EXECS();
        $molecule = $ch->filterthroughcmdSTERR($molecule, $execs['CHECKMOL'].' -m -');
    }
    return array($id, $molecule);
}

function formatForMolStatFGBCFP(&$inserts, &$result, &$dicts, $id)
{
    $tableMapping = TABLES_MAP();

    $molecule = $result->structure;
    
    $ch = new CmdHelper();
	$execs = EXECS();
    $ret = $ch->filterThroughCmdSTERR($molecule, $execs['CHECKMOL'].' -aXbH -');
    $retArray = preg_split('/\n/',$ret);
    
    $molStat  = $retArray[0];
    $molFGB   = $retArray[1];
	if(!isset($retArray[2]))
	{
		return false;
	}
    $molHFP   = preg_split('/,|;/', rtrim($retArray[2]));

    if ((strpos($molStat,"unknown") == false) && (strpos($molStat,"invalid") == false)) 
    {
        rtrim($molStat);
        $inserts[$tableMapping['stats']] = array_merge(array($id), preg_split('/,/',$molStat));
        $inserts[$tableMapping['fgb']] = array_merge(array($id), preg_split('/,|;/',$molFGB));
        $molDFP   = array($id);
        for ($k = 0; $k < count($dicts); $k++) 
        {
            $dict = $dicts[$k];
			$cand = $molecule . "\n" . '$$$$' ."\n" . $dict;
			if(!preg_match('/WIN/i',PHP_OS))
			{
				$cand = preg_replace('/\$/','\\\$', $cand);
			}
            $ret = $ch->filterThroughCmdSTERR($cand, $execs['MATCHMOL'].' -F -');
            $molDFP[] = str_replace("\n",'',trim($ret));
        }
        $inserts[$tableMapping['cfp']] = array_merge($molDFP, $molHFP);
    }
}

function isValidMol($testMol)
{
	$zeroLines = 0;
	$xyzLine = preg_split('/\n/', $testMol);
	for ($i = 0; $i < count($xyzLine); $i++)
	{
		$testLine = $xyzLine[$i];
		$testLine = preg_replace('/ +/',':', $testLine);
		$xyz = preg_split('/:/', $testLine);
		if(count($xyz) > 3)
		{
			$xval = $xyz[1];
			$yval = $xyz[2];
			$zval = $xyz[3];
			if ((strpos($xval,"0.0000") !== false) && (strpos($yval,"0.0000") !== false) && (strpos($zval,"0.0000") !== false)) 
			{ 
				$zeroLines++; 
			}
		}
	}

	return $zeroLines <= 1;
}


function formatPic2dStatus($status, $id) 
{
    return array($id, $status);
}


function createBitmap($molecule, $id, $baseDir, $mOpt, $sf)
{
	$execs = EXECS();
	if(!is_dir($baseDir.'/'.floor($id/1000)))
	{
		mkdir($baseDir.'/'.floor($id/1000));
	}
	$filename = floor($id/1000).'/'.$id.'.png';
    $gsdevice = "pnggray";
    if (strpos($mOpt,"--color=") >= 0) 
    { 
        $gsdevice = "png256"; 
    }
    $ch = new CmdHelper();
    $molps = $ch->filterThroughCmdSTERR($molecule, $execs['MOL2PS']." $mOpt - ");
    $bb =  $ch->filterThroughCmdSTERR($molps, $execs['GS']." -q -sDEVICE=bbox -dNOPAUSE -dBATCH  -r300 -g500000x500000 - ");  
    $bbRec =   preg_split('/\n/', $bb);
    $bbLores = trim(preg_replace('/%%BoundingBox:/','',$bbRec[0]));
    $bbCorner = preg_split('/ /', $bbLores);
    $bbLeft = $bbCorner[0];
    $bbBottom = $bbCorner[1];
    $bbRight = $bbCorner[2];
    $bbTop = $bbCorner[3];
    $xTotal = ($bbRight + $bbLeft) * $sf;
    $yTotal = ($bbTop + $bbBottom) * $sf;
    if (($xTotal > 0) && ($yTotal > 0)) 
    {
        $molps = $sf . " " . $sf . " scale\n" . $molps;  ## insert the PS "scale" command
        #print "low res: $bblores  .... max X: $bbright, max Y: $bbtop \n";
        #print "$filename  $xtotal x $ytotal pt\n";
    } 
    else 
    {
        $xTotal = 99;
        $yTotal = 55;
        $molps = "%!PS-Adobe
        /Helvetica findfont 14 scalefont setfont
        10 30 moveto
        (2D structure) show
        10 15 moveto
        (not available) show
        showpage\n";
    }	
    $gsopt1 = " -r300 -dGraphicsAlphaBits=4 -dTextAlphaBits=4 -dDEVICEWIDTHPOINTS=";
    $gsopt1 = $gsopt1 . $xTotal . " -dDEVICEHEIGHTPOINTS=" . $yTotal;
    $gsopt1 = $gsopt1 . " -sOutputFile=\"" . $baseDir.'/'.$filename."\"";
    $gscmd = $execs['GS'] . " -q -sDEVICE=$gsdevice -dNOPAUSE -dBATCH " . $gsopt1 . " - ";
    if(preg_match('/WIN/i',PHP_OS))
    {	
        #print "\n$molps\n $gscmd\n";
        $dummy = $ch->filterThroughCmdSTERR($molps, $gscmd);
    } 
    else 
    {
        exec("echo \"$molps\" |$gscmd");
    }
	return array($id, $filename);
}
?>