<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# SDFParser.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#
require_once('SDF.php');

class SDFParser
{
	private $filename;
	private $fh;
	
	public function __construct($f)
	{
		$this->filename = $f;
		$this->fh = false;
	}
	
	public function parse()
	{
		$sdfs = array();
		if(is_file($this->filename))
		{
			$this->fh = fopen($this->filename,'r');
			
			$i = 0;
			$state = 0;
			$name = '';
			$struct = array();
			$tag = '';
			$value = array();
			while($line = fgets($this->fh))
			{
				$line = rtrim($line);
				$hasTag = preg_match('/>\s+<(.+)>/', $line, $matches);
				
				if(strcmp($line, '$$$$') == 0)
				{
					$sdfs[$i]->editTag($tag, join("\n",$value));
					$i++;
					$state = 0;
				}
				else if($state == 0)
				{
					$name = $line;
					$struct = array();
					$state = 1;
				}
				else if(!$hasTag && $state == 1)
				{
					$struct[] = $line;
				}
				else if($hasTag && $state == 1)
				{
					$sdfs[$i] = new SDF($name, join("\n",$struct));
					$tag = $matches[1];
					$value = array();
					$state = 2;
				}
				else if(!$hasTag && $state == 2)
				{
					$value[] = $line;
				}
				else if($hasTag && $state == 2)
				{
					$sdfs[$i]->editTag($tag, join("\n",$value));
					$tag = $matches[1];
					$value = array();
				}
			}
			fclose($this->fh);
			$this->fh = false;
		}
		return $sdfs;	
	}
	
	public function parseNext()
	{
		$sdf = false;
		if(is_file($this->filename) && $this->fh === false)
		{
			$this->fh = fopen($this->filename,'r');
		}
		
		if($this->fh !== false)
		{
			$done = false;
			$state = 0;
			$name = '';
			$struct = array();
			$tag = '';
			$value = array();
			if($line = fgets($this->fh))
			{
				while(!$done && $line !== false)
				{
					$line = rtrim($line);
					$hasTag = preg_match('/>\s+<(.+)>/', $line, $matches);
					
					if(strcmp($line, '$$$$') == 0)
					{
						$sdf->editTag($tag, join("\n",$value));
						$done = true;
						$state = 0;
					}
					else if($state == 0)
					{
						$name = $line;
						$struct = array();
						$state = 1;
					}
					else if(!$hasTag && $state == 1)
					{
						$struct[] = $line;
					}
					else if($hasTag && $state == 1)
					{
						$sdf = new SDF($name, join("\n",$struct));
						$tag = $matches[1];
						$value = array();
						$state = 2;
					}
					else if(!$hasTag && $state == 2)
					{
						$value[] = $line;
					}
					else if($hasTag && $state == 2)
					{
						$sdf->editTag($tag, join("\n",$value));
						$tag = $matches[1];
						$value = array();
					}
					if(!$done)
					{					
						$line = fgets($this->fh);
					}
				}
			}
			else
			{
				fclose($this->fh);
				$this->fh = false;
			}
		}
		return $sdf;	
	}
}
?>