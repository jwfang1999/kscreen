<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# SQLBuilder.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#
class SQLBuilder
{
	private $fileName;
	
	public function SQLBuilder($f = 'result', $overWrite = false)
	{
		$n = 0;
		$fs = preg_split('/\./',$f);
		$this->fileName = $fs[0];
		if(!$overWrite)
		{
			while(is_file($this->fileName.'.sql'))
			{
				$this->fileName = $f.$n;
				$n++;
			}
		}
		$this->fileName .= '.sql';
	}
	
	public function getInsertStatements($sqlArray, $asArray = false)
	{
		$sql = false;
		if(is_array($sqlArray))
		{
			if($asArray)
			{
				$sql = array();
			}
			else
			{
				$sql = '';
			}
			foreach($sqlArray as $table => $protoStmt)
			{
				if(is_array($protoStmt))
				{
					if(SQLBuilder::isAssoc($protoStmt))
					{
						$tags = join('`,`',array_keys($protoStmt));
						
						foreach($protoStmt as $val)
						{
							$val = mysql_real_escape_string($val);
							if(is_numeric($val))
							{
								$vals[] = $val;
							}
							else
							{
								$vals[] = '"'.$val.'"';
							}
						}
						$vals = join(',', $vals);
						if($asArray)
						{
							$sql[] = 'INSERT INTO `'.$table.'` (`'.$tags.'`) VALUES ('.$vals.');';
						}
						else
						{
							$sql .= 'INSERT INTO `'.$table.'` (`'.$tags.'`) VALUES ('.$vals.');'."\n";
						}
					}
					else
					{
						$vals = array();
						foreach($protoStmt as $val)
						{
							$val = mysql_real_escape_string($val);
							if(is_numeric($val))
							{
								$vals[] = $val;
							}
							else
							{
								$vals[] = '"'.$val.'"';
							}
						}
						$vals = join(',', $vals);
						if($asArray)
						{
							$sql[] = 'INSERT INTO `'.$table.'` VALUES ('.$vals.');';
						}
						else
						{
							$sql .= 'INSERT INTO `'.$table.'` VALUES ('.$vals.');'."\n";
						}
					}
				}
			}
		}
		return $sql;
	}
	
	public function appendInsertStatements($sqlArray)
	{
		if(is_array($sqlArray))
		{
			$fh = fopen($this->fileName, 'a');
			$sql = $this->wrapTransaction($this->getInsertStatements($sqlArray));
			if(is_array($sql))
			{
				$sql = join("\n",$sql);
			}
			fwrite($fh,$sql);
			fclose($fh);
			return true;
		}
		return false;
	}
	
	public function writeInsertStatements($sqlArray)
	{
		if(is_array($sqlArray))
		{
			$fh = fopen($this->fileName, 'w');
			$sql = $this->wrapTransaction($this->getInsertStatements($sqlArray));
			if(is_array($sql))
			{
				$sql = join("\n",$sql);
			}
			fwrite($fh,$sql);
			fclose($fh);
			return true;
		}
		return false;
	}
	
	public function wrapTransaction($sql)
	{
		if($sql !== false)
		{
			if(is_array($sql))
			{
				$newSql = array('START TRANSACTION;');
				foreach($sql as $line)
				{
					$newSql[] = $line;
				}
				$newSql[] = 'COMMIT;';
				$sql = $newSql;
			}
			else
			{
				$sql = 'START TRANSACTION;'."\n".$sql.'COMMIT;'."\n";;
			}
		}
		return $sql;
	}
	
	private static function isAssoc($arr)
	{
		return array_keys($arr) !== range(0, count($arr) - 1);
	}
}
?>