library(prada)

###############################################################################################
#
#read one envision output file, by default, it handles 384 well plate, no positive/negative controls (need to be defined)
#mid_pct = 0.8 (used to calculate mean_mid (the mean of middle mid_pct percentage of activities) 
#
###############################################################################################
read_envision <- function(data_file, config_file, mid_pct=0.8){
	
	data_lines <- readLines(data_file);

	one_plate <- list();	# a plate data object

	one_plate$config <- read.table(config_file,sep=",");

	nrow <- dim(one_plate$config)[1];
	ncol <- dim(one_plate$config)[2];

	one_plate$raw_data <- array(dim=c(nrow, ncol)); #data is a matrix
	one_plate$POC_data <- array(dim=c(nrow, ncol)); #normalized by Percent of Control method
	one_plate$NPI_data <- array(dim=c(nrow, ncol)); #normalized by Normalized Percent Inhibition method
	one_plate$zscore_data <- array(dim=c(nrow, ncol)); #normalized by Z score method
	one_plate$PMN_data <- array(dim=c(nrow, ncol)); #normalized by plate median normalization

	i <- 0;
	for(line in data_lines){ #read activity data
	    i <- i + 1; 
	    if(i <= nrow){
			one_plate$raw_data[i,] <- as.numeric(unlist(strsplit(line, ",")));
	    }
	}

	one_plate$name <- data_file;

	#NAs are ignored
	pos_control <- na.omit(one_plate$raw_data[one_plate$config == "P"]);
	neg_control <- na.omit(one_plate$raw_data[one_plate$config == "N"]);
	data <- na.omit(one_plate$raw_data[one_plate$config != "P" & one_plate$config != "N" & one_plate$config != "E" & one_plate$raw_data != "F"]); 
	
	print (one_plate$name);
	print ("data are:");
	print(data);

	if(length(neg_control) == 0){ #if there is no negative control
		if(length(pos_control) == 0){ #no positive control 
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- NA;
			one_plate$median_pos_control <- NA;
			one_plate$sd_pos_control <- NA;
			one_plate$mean_neg_control <- NA;
			one_plate$median_neg_control <- NA;
			one_plate$sd_neg_control <- NA;
			one_plate$z_factor <- NA;
			one_plate$z_prime_factor <- NA;
			one_plate$POC_data <- NA;
			one_plate$NPI_data <- NA;

			if(is.na(one_plate$sd_samples))
			{
				one_plate$sd_samples = 0;
			}
			if(one_plate$sd_samples != 0){
				one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			}
			
			if(is.na(one_plate$median_samples))
			{
				one_plate$median_samples = 0;
			}			
			if(one_plate$median_samples != 0){	
				one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;
			}

			one_plate$mean_mid <- mean_mid(data, mid_pct);		
		}
	
		else{
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- mean(pos_control);
			one_plate$median_pos_control <- median(pos_control);
			one_plate$sd_pos_control <- sd(pos_control);
			one_plate$mean_neg_control <- NA;
			one_plate$median_neg_control <- NA;
			one_plate$sd_neg_control <- NA;
			one_plate$z_factor <- NA;
			one_plate$z_prime_factor <- NA;

			if(one_plate$mean_pos_control != 0) {
				one_plate$POC_data <- (one_plate$raw_data)/one_plate$mean_pos_control;
			}

			one_plate$NPI_data <- NA;

			if(is.na(one_plate$sd_samples))
			{
				one_plate$sd_samples = 0;
			}
			if(one_plate$sd_samples != 0){
				one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			}
			
			if(is.na(one_plate$median_samples))
			{
				one_plate$median_samples = 0;
			}
			if(one_plate$median_samples != 0){	
				one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;
			}

			one_plate$mean_mid <- mean_mid(data, mid_pct);	
		}
	}
	else{ #there is negative control
		if(length(pos_control) == 0){ #no positive control 
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- NA;
			one_plate$median_pos_control <- NA;
			one_plate$sd_pos_control <- NA;
			one_plate$mean_neg_control <- mean(neg_control);
			one_plate$median_neg_control <- median(neg_control);
			one_plate$sd_neg_control <- sd(neg_control);
			one_plate$z_factor <- NA;
			one_plate$z_prime_factor <- NA;
			one_plate$POC_data <- NA;
			one_plate$NPI_data <- NA;

			if(is.na(one_plate$sd_samples))
			{
				one_plate$sd_samples = 0;
			}
			if(one_plate$sd_samples != 0){
				one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			}
			
			if(is.na(one_plate$median_samples))
			{
				one_plate$median_samples = 0;
			}
			if(one_plate$median_samples != 0){	
				one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;
			}

			one_plate$mean_mid <- mean_mid(data, mid_pct);	
		}
		else{
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- mean(pos_control);
			one_plate$median_pos_control <- median(pos_control);
			one_plate$sd_pos_control <- sd(pos_control);
			one_plate$mean_neg_control <- mean(neg_control);
			one_plate$median_neg_control <- median(neg_control);
			one_plate$sd_neg_control <- sd(neg_control);

			if ((one_plate$mean_pos_control - one_plate$mean_neg_control) != 0){
				one_plate$z_factor <- 1 - 3 * (one_plate$sd_pos_control + one_plate$sd_neg_control)/abs(one_plate$mean_pos_control - one_plate$mean_neg_control);
				one_plate$z_prime_factor <- (abs(one_plate$mean_pos_control - one_plate$mean_neg_control) - abs(3*(one_plate$sd_pos_control + one_plate$sd_neg_control)))/abs(one_plate$mean_pos_control - one_plate$mean_neg_control);
			}

			if(one_plate$mean_pos_control != 0) {
				one_plate$POC_data <- (one_plate$raw_data)/one_plate$mean_pos_control;
			}

			one_plate$NPI_data <- (one_plate$raw_data - one_plate$mean_neg_control)/(one_plate$mean_pos_control - one_plate$mean_neg_control);

			if(is.na(one_plate$sd_samples))
			{
				one_plate$sd_samples = 0;
			}
			if(one_plate$sd_samples != 0){
				one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			}
			
			if(is.na(one_plate$median_samples))
			{
				one_plate$median_samples = 0;
			}
			if(one_plate$median_samples != 0){	
				one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;
			}

			one_plate$mean_mid <- mean_mid(data, mid_pct);	


			#print ("pmn_data is:");
			#print(one_plate$PMN_data);

		}
	}

	return(one_plate);
}



######################################################
#
#used to a set of data files along with their configuration files, returns a list of plate objects
#
#####################################################
read_plate_batch <- function(path = ".", data_files, config_files, import_function, mid_pct=0.8, verbose=interactive()){
	plates <- list();
	for(i in 1:length(data_files)){
		plates[[i]] <- import_function(paste(path,data_files[i],sep=""), paste(path,config_files[i],sep=""), mid_pct);
	}
	return(plates);	
}

plot_one_plate <- function(data_array, config_array, nrow=16, ncol=24, main_title="Title", col=c("#0000e0", "white", "#e00000")){
	library(prada);	

	config_array <- config_array;
	config_array[config_array != "P" & config_array != "N" & config_array != "E"] <- NA;	 #label positives, negatives, and empty wells.  


	#print ("data_array is");
	#print (data_array);

	#print ("config_array is");
	#print (config_array);

	plotPlate(data_array, char=config_array[,1], nrow=16, ncol=24, main=main_title, col=c("#0000e0", "white", "#e00000"), na.action="xout"); #na.action used to label failed wells



#need to reformat data matrix to one-dimensional data vector.  Also it seems it is necessary to transpose the array, otherwise plotPlate won�t array col and row in a correct way.     

}


print_one_plate_jpeg <- function(data_array, config_array, filename="out.jpeg", title="", x=1500, y=1000, units = "px", pointsize = 12, quality = 100, bg = "white", res = 96, restoreConsole = TRUE){
##############################################
#
#take a plate object, output file name as input, output is a jpeg file
#
#################################################
	jpeg(filename = filename, width = x, height = y, units = units, pointsize = pointsize, quality = quality, bg = bg, res = res);
	plot_one_plate(data_array, config_array, main_title=title);
	dev.off();
}


print_one_plate_jpeg2 <- function(data_array, config_array,filename="out.jpeg", title="", x=400, y=300, units = "px", pointsize = 12, quality = 100, bg = "white", res = 96, restoreConsole = TRUE){
##############################################
#
#take a plate object, output file name as input, output is a jpeg file
#
#################################################
	jpeg(filename = filename, width = x, height = y, units = units, pointsize = pointsize, quality = quality, bg = bg, res = res);
	plot_one_plate(data_array, config_array, main_title=title);
	dev.off();
}

print_one_plate_jpeg3 <- function(data_array, config_array, filename="out.jpeg", title="", x=800, y=600, units = "px", pointsize = 12, quality = 100, bg = "white", res = 96, restoreConsole = TRUE){
	jpeg(filename = filename, width = x, height = y, units = units, pointsize = pointsize, quality = quality, bg = bg, res = res);
	plot_one_plate(data_array, config_array, main_title=title);
	dev.off();
}


print_all_jpegs <- function(plates, x=1500, y=1000){
	num_plates <- length(plates);
	for(i in 1:num_plates){

		data_array <- array(t(plates[[i]]$raw_data), c(384, 1));

		config_array <-  array(t(plates[[i]]$config), c(384, 1));
			

		filename = paste(plates[[i]]$name, ".jpeg", sep="");
		print_one_plate_jpeg(data_array, config_array, filename=filename, title=filename);
		write.table(data_array, file = paste(plates[[i]]$name, ".txt", sep=""), sep = ",");
	
		if(!is.na(plates[[i]]$POC_data)){
			POC_data_array <- array(t(plates[[i]]$POC_data), c(384, 1));
			POC_filename = paste(plates[[i]]$name, ".poc.jpeg", sep="");
			print_one_plate_jpeg(POC_data_array,config_array,filename=POC_filename, title=POC_filename);
			write.table(POC_data_array, file = paste(plates[[i]]$name, ".poc.txt", sep=""), sep = ",");
		}

		if(!is.na(plates[[i]]$NPI_data)){
			NPI_data_array <- array(t(plates[[i]]$NPI_data), c(384, 1));
			NPI_filename = paste(plates[[i]]$name, ".npi.jpeg", sep="");
			print_one_plate_jpeg(NPI_data_array,config_array,filename=NPI_filename, title=NPI_filename);
			write.table(NPI_data_array, file = paste(plates[[i]]$name, ".npi.txt", sep=""), sep = ",");
		}

		if(!is.na(plates[[i]]$zscore_data)){
			zscore_data_array <- array(t(plates[[i]]$zscore_data), c(384, 1));
			zscore_filename = paste(plates[[i]]$name, ".zscore.jpeg", sep="");
			print_one_plate_jpeg(zscore_data_array,config_array,filename=zscore_filename, title=zscore_filename);
			write.table(zscore_data_array, file = paste(plates[[i]]$name, ".zscore.txt", sep=""), sep = ",")
		}	

		if(!is.na(plates[[i]]$PMN_data)){
			PMN_data_array <- array(t(plates[[i]]$PMN_data), c(384, 1));
			PMN_filename = paste(plates[[i]]$name, ".pmn.jpeg", sep="");
			print_one_plate_jpeg(PMN_data_array,config_array,filename=PMN_filename, title=PMN_filename);
			write.table(PMN_data_array, file = paste(plates[[i]]$name, ".pmn.txt", sep=""), sep = ",");
		}
	}	
}

print_all_jpegs2 <- function(plates, x=400, y=300){
	num_plates <- length(plates);
	for(i in 1:num_plates){

		data_array <- array(t(plates[[i]]$raw_data), c(384, 1));

		config_array <-  array(t(plates[[i]]$config), c(384, 1));

		filename = paste(plates[[i]]$name, ".thumb.jpeg", sep="");
		print_one_plate_jpeg2(data_array,config_array,filename=filename, title=filename);
			
		if(!is.na(plates[[i]]$POC_data)){
			POC_data_array <- array(t(plates[[i]]$POC_data), c(384, 1));
			POC_filename = paste(plates[[i]]$name, ".poc.thumb.jpeg", sep="");
			print_one_plate_jpeg2(POC_data_array,config_array,filename=POC_filename, title=POC_filename);
		}

		if(!is.na(plates[[i]]$NPI_data)){
			NPI_data_array <- array(t(plates[[i]]$NPI_data), c(384, 1));
			NPI_filename = paste(plates[[i]]$name, ".npi.thumb.jpeg", sep="");
			print_one_plate_jpeg2(NPI_data_array,config_array,filename=NPI_filename, title=NPI_filename);
		}

		if(!is.na(plates[[i]]$zscore_data)){
			zscore_data_array <- array(t(plates[[i]]$zscore_data), c(384, 1));
			zscore_filename = paste(plates[[i]]$name, ".zscore.thumb.jpeg", sep="");
			print_one_plate_jpeg2(zscore_data_array,config_array,filename=zscore_filename, title=zscore_filename);
		}	

		if(!is.na(plates[[i]]$PMN_data)){
			PMN_data_array <- array(t(plates[[i]]$PMN_data), c(384, 1));
			PMN_filename = paste(plates[[i]]$name, ".pmn.thumb.jpeg", sep="");
			print_one_plate_jpeg2(PMN_data_array,config_array,filename=PMN_filename, title=PMN_filename);
		}
	}	
}


############################################################
#
#take a plate data (array(dim=c(nrow, ncol)) and positive and negative control rows
#return the mean of midle of mid_pct percent of the activities 
#
###########################################################
mean_mid <- function(data, mid_pct){
	sorted_data <- sort(data);
	length <- length(sorted_data);
	ceiling <- ceiling((1-mid_pct)*length/2);
	floor <- floor((1-(1-mid_pct)/2)*length);
	mid_mean <- mean(sorted_data[ceiling:floor]);
	return(mid_mean);
}



###############################################################################################
#
#read one safire output file in csv format, the configure of the plate is read from the configuration file
#mid_pct = 0.8 (used to calculate mean_mid (the mean of middle mid_pct percentage of activities) 
#the forth paramater, escape is the number of lines above the real data
#
###############################################################################################
read_safire <- function(data_file, config_file, mid_pct=0.8, escape = 15){
	
	data_lines <- readLines(data_file);

	one_plate <- list();	# a plate data object
	
	one_plate$config <- read.table(config_file,sep=",");
#	one_plate$config <- read.table(config_file);
	nrow <- dim(one_plate$config)[1];
	ncol <- dim(one_plate$config)[2];


	one_plate$raw_data <- array(dim=c(nrow, ncol)); #data is a matrix
	one_plate$POC_data <- array(dim=c(nrow, ncol)); #normalized by Percent of Control method
	one_plate$NPI_data <- array(dim=c(nrow, ncol)); #normalized by Normalized Percent Inhibition method
	one_plate$zscore_data <- array(dim=c(nrow, ncol)); #normalized by Z score method
	one_plate$PMN_data <- array(dim=c(nrow, ncol)); #normalized by plate median normalization

	i <- 1;
	for(line in data_lines[escape:(escape+nrow-1)]){ #read activity data
		one_plate$raw_data[i,] <- as.numeric(unlist(strsplit(line, ","))[-1]); #skip the first column, the row ID
		#one_plate$raw_data[i,] <- as.numeric(unlist(strsplit(line, ",")));
		i <- i + 1;
	}

	one_plate$name <- data_file;

	pos_control <- one_plate$raw_data[one_plate$config == "P"];
	neg_control <- one_plate$raw_data[one_plate$config == "N"];
	data <- one_plate$raw_data[one_plate$config != "P" & one_plate$config != "N" & one_plate$config != "E" & one_plate$config != "F"];


	if(length(neg_control) == 0){ #if there is no negative control
		if(length(pos_control) == 0){ #no positive control 
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- NA;
			one_plate$median_pos_control <- NA;
			one_plate$sd_pos_control <- NA;
			one_plate$mean_neg_control <- NA;
			one_plate$median_neg_control <- NA;
			one_plate$sd_neg_control <- NA;
			one_plate$z_factor <- NA;
			one_plate$z_prime_factor <- NA;
			one_plate$POC_data <- NA;
			one_plate$NPI_data <- NA;
			one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;

			one_plate$mean_mid <- mean_mid(data, mid_pct);		
		}
	
		else{
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- mean(pos_control);
			one_plate$median_pos_control <- median(pos_control);
			one_plate$sd_pos_control <- sd(pos_control);
			one_plate$mean_neg_control <- NA;
			one_plate$median_neg_control <- NA;
			one_plate$sd_neg_control <- NA;
			one_plate$z_factor <- NA;
			one_plate$z_prime_factor <- NA;
			one_plate$POC_data <- (one_plate$raw_data)/one_plate$mean_pos_control;
			one_plate$NPI_data <- NA;
			one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;

			one_plate$mean_mid <- mean_mid(data, mid_pct);	
		}
	}
	else{ #there is negative control
		if(length(pos_control) == 0){ #no positive control 
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- NA;
			one_plate$median_pos_control <- NA;
			one_plate$sd_pos_control <- NA;
			one_plate$mean_neg_control <- mean(neg_control);
			one_plate$median_neg_control <- median(neg_control);
			one_plate$sd_neg_control <- sd(neg_control);
			one_plate$z_factor <- NA;
			one_plate$z_prime_factor <- NA;
			one_plate$POC_data <- NA;
			one_plate$NPI_data <- NA;
			one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;
			one_plate$mean_mid <- mean_mid(data, mid_pct);	
		}
		else{
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- mean(pos_control);
			one_plate$median_pos_control <- median(pos_control);
			one_plate$sd_pos_control <- sd(pos_control);
			one_plate$mean_neg_control <- mean(neg_control);
			one_plate$median_neg_control <- median(neg_control);
			one_plate$sd_neg_control <- sd(neg_control);
			one_plate$z_factor <- 1 - 3 * (one_plate$sd_pos_control + one_plate$sd_neg_control)/abs(one_plate$mean_pos_control - one_plate$mean_neg_control);
			one_plate$z_prime_factor <- (abs(one_plate$mean_pos_control - one_plate$mean_neg_control) - (3*(one_plate$sd_pos_control + one_plate$sd_neg_control)))/abs(one_plate$mean_pos_control - one_plate$mean_neg_control);
			one_plate$POC_data <- (one_plate$raw_data)/one_plate$mean_pos_control;
			one_plate$NPI_data <- (one_plate$raw_data - one_plate$mean_neg_control)/(one_plate$mean_pos_control - one_plate$mean_neg_control);
			one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;
			one_plate$mean_mid <- mean_mid(data, mid_pct);	
		}
	}

	return(one_plate);
}




###############################################################################################
#
#read one spectramax output file in csv format, the configure of the plate is read from the configuration file
#mid_pct = 0.8 (used to calculate mean_mid (the mean of middle mid_pct percentage of activities) 
#the forth paramater, escape is the number of lines above the real data
#
###############################################################################################
read_spectramax <- function(data_file, config_file, mid_pct=0.8, escape = 15){
	
	data_lines <- readLines(data_file);

	one_plate <- list();	# a plate data object

	one_plate$config <- read.table(config_file,sep=",");
#	one_plate$config <- read.table(config_file);
	nrow <- dim(one_plate$config)[1];
	ncol <- dim(one_plate$config)[2];


	one_plate$raw_data <- array(dim=c(nrow, ncol)); #data is a matrix
	one_plate$POC_data <- array(dim=c(nrow, ncol)); #normalized by Percent of Control method
	one_plate$NPI_data <- array(dim=c(nrow, ncol)); #normalized by Normalized Percent Inhibition method
	one_plate$zscore_data <- array(dim=c(nrow, ncol)); #normalized by Z score method
	one_plate$PMN_data <- array(dim=c(nrow, ncol)); #normalized by plate median normalization

	i <- 1;
	for(line in data_lines[4:(nrow+3)]){ #skep first four lines and start to read activity data
	    line <- sub("^[[:space:]]+", "", line);
	    one_plate$raw_data[i,] <- as.numeric(unlist(strsplit(line, "[[:space:]]+")));	
 	    i <- i + 1;
	}

	one_plate$name <- data_file;

	pos_control <- one_plate$raw_data[one_plate$config == "P"];
	neg_control <- one_plate$raw_data[one_plate$config == "N"];
	data <- one_plate$raw_data[one_plate$config != "P" & one_plate$config != "N" & one_plate$config != "E" & one_plate$config != "F"];


	if(length(neg_control) == 0){ #if there is no negative control
		if(length(pos_control) == 0){ #no positive control 
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- NA;
			one_plate$median_pos_control <- NA;
			one_plate$sd_pos_control <- NA;
			one_plate$mean_neg_control <- NA;
			one_plate$median_neg_control <- NA;
			one_plate$sd_neg_control <- NA;
			one_plate$z_factor <- NA;
			one_plate$z_prime_factor <- NA;
			one_plate$POC_data <- NA;
			one_plate$NPI_data <- NA;
			one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;

			one_plate$mean_mid <- mean_mid(data, mid_pct);		
		}
	
		else{
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- mean(pos_control);
			one_plate$median_pos_control <- median(pos_control);
			one_plate$sd_pos_control <- sd(pos_control);
			one_plate$mean_neg_control <- NA;
			one_plate$median_neg_control <- NA;
			one_plate$sd_neg_control <- NA;
			one_plate$z_factor <- NA;
			one_plate$z_prime_factor <- NA;
			one_plate$POC_data <- (one_plate$raw_data)/one_plate$mean_pos_control;
			one_plate$NPI_data <- NA;
			one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;

			one_plate$mean_mid <- mean_mid(data, mid_pct);	
		}
	}
	else{ #there is negative control
		if(length(pos_control) == 0){ #no positive control 
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- NA;
			one_plate$median_pos_control <- NA;
			one_plate$sd_pos_control <- NA;
			one_plate$mean_neg_control <- mean(neg_control);
			one_plate$median_neg_control <- median(neg_control);
			one_plate$sd_neg_control <- sd(neg_control);
			one_plate$z_factor <- NA;
			one_plate$z_prime_factor <- NA;
			one_plate$POC_data <- NA;
			one_plate$NPI_data <- NA;
			one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;
			one_plate$mean_mid <- mean_mid(data, mid_pct);	
		}
		else{
			one_plate$mean_samples <- mean(data);
			one_plate$sd_samples <- sd(data);
			one_plate$median_samples <- median(data);
			one_plate$mean_pos_control <- mean(pos_control);
			one_plate$median_pos_control <- median(pos_control);
			one_plate$sd_pos_control <- sd(pos_control);
			one_plate$mean_neg_control <- mean(neg_control);
			one_plate$median_neg_control <- median(neg_control);
			one_plate$sd_neg_control <- sd(neg_control);
			one_plate$z_factor <- 1 - 3 * (one_plate$sd_pos_control + one_plate$sd_neg_control)/abs(one_plate$mean_pos_control - one_plate$mean_neg_control);
			one_plate$z_prime_factor <- (abs(one_plate$mean_pos_control - one_plate$mean_neg_control) - (3*(one_plate$sd_pos_control + one_plate$sd_neg_control)))/abs(one_plate$mean_pos_control - one_plate$mean_neg_control);
			one_plate$POC_data <- (one_plate$raw_data)/one_plate$mean_pos_control;
			one_plate$NPI_data <- (one_plate$raw_data - one_plate$mean_neg_control)/(one_plate$mean_pos_control - one_plate$mean_neg_control);
			one_plate$zscore_data <- (one_plate$raw_data - one_plate$mean_samples)/one_plate$sd_samples; 
			one_plate$PMN_data <- one_plate$raw_data/one_plate$median_samples;
			one_plate$mean_mid <- mean_mid(data, mid_pct);	
		}
	}

	return(one_plate);
}

