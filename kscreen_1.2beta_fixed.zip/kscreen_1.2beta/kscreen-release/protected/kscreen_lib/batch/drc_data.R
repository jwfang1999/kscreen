#####################################
#
#David Tai, Applied Bioinformatics Lab, University of Kansas
#
#
##########################################

library(drc)
library(MASS)

sort_by_r_squared <- function(lst)
{
	ordering <- array(dim=c(length(lst),2))
	i <- 0
	for(ele in lst)
	{
		i <- i + 1
		ordering[i,] <- c(i,abs(1-ele["r2"]))
	}
	lst_order = ordering[order(ordering[,2]),1]

	ret_lst = list()
	i <- 0
	for(ele_order in lst_order)
	{
		i <- i + 1
		ret_lst[[i]] <- lst[[ele_order]]
	}
	return(ret_lst)
}

doSigmoid <- function(x,y,z)
{
	sig_fm = drm(y~x, fct = LL.4(fixed=c(z[1], z[2], z[3], z[4]), name = c("hs","b","t","ic50")))
	sig_coefs = coef(sig_fm)
	
	if(!is.na(z[1]))
	{
		sig_coefs["hs:(Intercept)"] = z[1];
	}
	if(!is.na(z[2]))
	{
		sig_coefs["b:(Intercept)"] = z[2];
	}
	if(!is.na(z[3]))
	{
		sig_coefs["t:(Intercept)"] = z[3];
	}
	if(!is.na(z[4]))
	{
		sig_coefs["ic50:(Intercept)"] = z[4];
	}

	temp_coefs = c();
	temp_coefs["hs:(Intercept)"] = sig_coefs["hs:(Intercept)"];
	temp_coefs["b:(Intercept)"] = sig_coefs["b:(Intercept)"];
	temp_coefs["t:(Intercept)"] = sig_coefs["t:(Intercept)"];
	temp_coefs["ic50:(Intercept)"] = sig_coefs["ic50:(Intercept)"];

	sig_coefs = temp_coefs;

	y_fit = fitted(sig_fm)
	y_avg = sum(y)/length(y)
	
	ss_total = sum((y-y_avg)*(y-y_avg))
	ss_error = sum((y-y_fit)*(y-y_fit))
	r_squared = 1 - ss_error/ss_total
	
	sig_ret = c("Sigmoid" = NA,sig_coefs,"r2" = r_squared)
	return(sig_ret);
}

doBrain_Cousens <- function(x,y,z)
{
	bc_fm = drm(y~x, fct = BC.5(fixed=c(z[1], z[2], z[3], z[4], z[5]), name = c("b","c","d","e","f")))
	bc_coefs = coef(bc_fm)

	if(!is.na(z[1]))
	{
		bc_coefs["b:(Intercept)"] = z[1];
	}
	if(!is.na(z[2]))
	{
		bc_coefs["c:(Intercept)"] = z[2];
	}
	if(!is.na(z[3]))
	{
		bc_coefs["d:(Intercept)"] = z[3];
	}
	if(!is.na(z[4]))
	{
		bc_coefs["e:(Intercept)"] = z[4];
	}
	if(!is.na(z[5]))
	{
		bc_coefs["f:(Intercept)"] = z[5];
	}

	temp_coefs = c();
	temp_coefs["b:(Intercept)"] = bc_coefs["b:(Intercept)"];
	temp_coefs["c:(Intercept)"] = bc_coefs["c:(Intercept)"];
	temp_coefs["d:(Intercept)"] = bc_coefs["d:(Intercept)"];
	temp_coefs["e:(Intercept)"] = bc_coefs["e:(Intercept)"];
	temp_coefs["f:(Intercept)"] = bc_coefs["f:(Intercept)"];

	bc_coefs = temp_coefs;

	y_fit = fitted(bc_fm)
	y_avg = sum(y)/length(y)
	
	ss_total = sum((y-y_avg)*(y-y_avg))
	ss_error = sum((y-y_fit)*(y-y_fit))
	r_squared = 1 - ss_error/ss_total
	
	bc_ret = c("Brain-Cousens" = NA, bc_coefs,"r2" = r_squared)
	return(bc_ret);
}

write_to_file <- function(lst, dest_file)
{
	for(ele in lst)
		write.table(ele, file = dest_file, append=TRUE, col.names=FALSE)
}

args = commandArgs()
src_file = args[6]

points <- read.csv(file=src_file)
x <- points$x
y <- points$y
z <- points$z

results = list()

file.remove(src_file)
file.create(src_file)

try(results$sig <- doSigmoid(x,y,z))
try(results$bc <- doBrain_Cousens(x,y,z))
results$nf = c("NoFit" = NA)

write_to_file(results,src_file)
write.table(z, file = src_file, append=TRUE, col.names=FALSE)
