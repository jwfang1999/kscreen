<?php
#
# Copyright 2010-2011 David Tai and Jianwen Fang, University of Kansas
# forkProcForeach.php is part of K-Screen Version 1.2.
#
# K-Screen is free software: you can redistribute it and/or modify it under 
# the terms of the GNU General Public License as published by the Free 
# Software Foundation, either version 3 of the License, or (at your option) 
# any later version.
#
# K-Screen is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
# details.
#
# Visit http://www.gnu.org/licenses/ to review a copy of the license.
#
$execThis 	= $argv[1];
$dir		= $argv[2];
$filter		= $argv[3];
$output   	= $argv[4];

if(is_file($output))
{
    unlink($output);
}

$files = glob($dir.$filter);
//echo "\n$dir.$filter\n";

$size = count($files);
$fh = fopen($output, 'w');
fwrite($fh, $size.' File(s) Total'."\n");

$num = 0;
foreach($files as $file)
{
	$num++;
	$fh = fopen($output, 'a');
	fwrite($fh, $num.' - Attempting File '.basename($file)."\n");
	fclose($fh);
	
	exec($execThis.' "'.$file.'"');
}

$fh = fopen($output, 'a');
fwrite($fh, 'COMPLETED');
fclose($fh);
?>