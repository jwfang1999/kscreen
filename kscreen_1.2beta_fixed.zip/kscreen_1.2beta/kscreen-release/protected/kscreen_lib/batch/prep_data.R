#####################################
#
#Jianwen Fang, Applied Bioinformatics Lab, University of Kansas
#
#Modified on Nov 23, 2009, now it can handle envision, safire, spectramax readers
#
##########################################

source("protected/kscreen_lib/batch/chemHTS.R")
library(lattice)

args = commandArgs();

nrow=args[10];
ncol=args[11];
neg_control_col=1
pos_control_col=2
mid_pct = 0.8



##################################################
#
#the following parameters need to be set if the script is not called from perl
#
#
#
###################################################

upload_dir = args[6];
upload_dir = gsub('\'', '', upload_dir); ## spaces only
#upload_dir = "D:\\Program Files\\Apache Software Foundation\\Apache2.2\\htdocs\\moldb5\\uploads\\os_test\\";

#print (upload_dir);

cat(args[6], "\n", sep = "");

###########################################
#
# the data files and their corresponding config files should have same name except the first (or a few) letter
# the first letter(s) are used to group data files and config files
#
#############################################
#args[9]
data_file_name_pattern = args[7];  # e.g. "^D"
#data_file_name_pattern = "^A";

config_file_name_pattern = args[8]; # e.g. "^C"
#config_file_name_pattern = "^C";
 
reader_type = args[9]; #currently support "safire", "spectramax", "envision"
#reader_type = "post";

#########################################################################
#
#end of parameter setting
#
#########################################################################


data_files = dir(upload_dir, data_file_name_pattern);

#print (data_files);

data_files = sort(data_files); 
config_files = dir(upload_dir, config_file_name_pattern);
config_files <- sort(config_files);

if(reader_type == "safire"){
	import_function <- read_safire;
}
if(reader_type == "spectramax"){
	import_function <- read_spectramax;
}
if(reader_type == "envision" || reader_type == "post"){
	import_function <- read_envision;
}

all_plates <- read_plate_batch(path = upload_dir,data_files, config_files, import_function=import_function, mid_pct=mid_pct);

print_all_jpegs(all_plates, x=1500, y=1000); #generate heatmaps for raw and normalized data
num_plates <- length(all_plates);

medians <- array(dim=c(nrow, ncol)); #medians is a matrix of medians across many plates

for(i in 1:nrow){
	for(j in 1:ncol){
		one_median <- c();
		for(k in 1:num_plates){
			one_median <- c(one_median, all_plates[[k]]$raw_data[i,j]);
		}
		medians[i,j] <- median(one_median, na.rm = TRUE); #NAs are stripped 
	}
}

print_one_plate_jpeg(array(t(medians), c(384, 1)), config_array = array(NA, c(384,1)), filename= paste(upload_dir,"/summary/well_median.jpeg",sep=""), title="The medians of wells");

print_one_plate_jpeg3(array(t(medians), c(384, 1)),config_array = array(NA, c(384,1)), filename= paste(upload_dir,"/summary/well_median.thumb.jpeg",sep=""), title="The medians of wells");


write.table(array(t(medians), c(384, 1)), file = paste(upload_dir,"/summary/well_median.txt",sep=""), sep = ",");


median_neg_controls <- array();
median_pos_controls <- array();
median_samples <- array();
z_prime_scores <- array();
plate_names <- array();

mid_means <- array(); #mean of central certain percentage of actitivies (ususally 80%)

cat("Beginning...<br>\n");

for(k in 1:num_plates){
	cat("Start Plate...<br>\n");
	median_neg_controls[k] <- all_plates[[k]]$median_neg_control;
	median_pos_controls[k] <- all_plates[[k]]$median_pos_control;
	median_samples[k] <- all_plates[[k]]$median_samples;
	z_prime_scores[k] <- all_plates[[k]]$z_prime_factor;

	mid_means[k] <- all_plates[[k]]$mean_mid;

	plate_names[k] <- all_plates[[k]]$name;
	cat("Plate Done...<br>\n");
}

#print ("median_neg_control");
#print (median_neg_controls);0
#print ("median_pos_control");
#print (median_pos_controls);
#print ("median_neg_control");
#print (median_neg_controls);
#print ("z_prime_scores");
#print (z_prime_scores);
#print ("mid_means");
#print (mid_means);
#print ("plate_names");
#print (plate_names);


cat("All Plates Done...<br>\n");

cat("Calculating Screen Statistics...<br>\n");

jpeg(filename = paste(upload_dir,"/summary/z_prime.jpeg",sep=""), width = 1500, height = 750, units = "px", pointsize = 2, quality = 100, bg = "white", res = 96);
barchart(z_prime_scores~plate_names, ylim=c(0,1), ylab="z\'", xlab="plate number", scales=list(x=list(rot=90,cex=0.8),y=list(cex=1)),main="Z\' factors of all plates");
dev.off();

write.table(z_prime_scores, file = paste(upload_dir,"/summary/z_prime.txt",sep=""), sep = ",");

jpeg(filename = paste(upload_dir,"/summary/mid_mean.jpeg",sep=""), width = 1500, height = 750, units = "px", pointsize = 2, quality = 100, bg = "white", res = 96);
barchart(mid_means~plate_names, ylim=c(min(mid_means)-(max(mid_means) - min(mid_means))/8,max(mid_means)+(max(mid_means) - min(mid_means))/8), ylab="mean of middle 80% activities", xlab="plate number", scales=list(x=list(rot=90,cex=0.8),y=list(cex=1)),main="mean of mid 80% of all plates");
dev.off();

write.table(mid_means, file = paste(upload_dir,"/summary/mid_mean.txt",sep=""), sep = ",");

jpeg(filename = paste(upload_dir,"/summary/medians.jpeg",sep=""), width = 1500, height = 750, units = "px", pointsize = 2, quality = 100, bg = "white", res = 96);
dotplot(median_neg_controls + median_pos_controls + median_samples~plate_names,  ylim=c(min(c(median_neg_controls, median_pos_controls, median_samples))-(max(c(median_neg_controls, median_pos_controls, median_samples)) - min(c(median_neg_controls, median_pos_controls, median_samples)))/8,max(c(median_neg_controls, median_pos_controls, median_samples))+(max(c(median_neg_controls, median_pos_controls, median_samples)) - min(c(median_neg_controls, median_pos_controls, median_samples)))/8), ylab="activity", xlab="plate number", scales=list(x=list(rot=90,cex=0.8),y=list(cex=1)),main="medians of negative control, positive control, samples of all plates", type=c("p","l"),lattice.options(autokey=T),auto.key = list(x = 0.5, y = 0.1, corner = c(0, 0), lines=TRUE,points=FALSE, cex=0.7));
dev.off();

write.table(median_neg_controls + median_pos_controls + median_samples, file = paste(upload_dir,"/summary/medians.txt",sep=""), sep = ",");

save_image = paste(upload_dir,"/.RData",sep="");
save.image(save_image);

cat("Calculating Screen Statistics Done...<br>\n");
 

